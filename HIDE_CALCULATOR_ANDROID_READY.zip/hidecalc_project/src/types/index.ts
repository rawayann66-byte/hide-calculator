export type VaultMediaType = 'photo' | 'video' | 'file';

export interface VaultFileItem {
  id: string;
  name: string;
  type: VaultMediaType;
  mimeType: string;
  size: number;
  createdAt: number;
  encryptedData: ArrayBuffer; // 12-byte IV + AES-GCM ciphertext
  thumbnailData?: ArrayBuffer; // Optional encrypted thumbnail
  notes?: string;
}

export interface DecryptedFileItem {
  id: string;
  name: string;
  type: VaultMediaType;
  mimeType: string;
  size: number;
  createdAt: number;
  blobUrl: string;
  notes?: string;
  blob?: Blob;
}

export interface VaultNote {
  id: string;
  title: string;
  encryptedContent: ArrayBuffer; // IV + ciphertext
  updatedAt: number;
}

export interface DecryptedNote {
  id: string;
  title: string;
  content: string;
  updatedAt: number;
}

export interface VaultConfig {
  isSetup: boolean;
  pinSalt: string; // Base64 salt for PBKDF2 PIN verification
  pinHash: string; // Base64 PBKDF2 hash
  vaultSalt: string; // Base64 salt for AES-GCM key derivation
  autoLockDelay: number; // In seconds (0 = immediate, 60 = 1 min, etc.)
  lockOnBlur: boolean;
  hapticSound: boolean;
  panicAction: 'calculator' | 'fake_crash';
  lastUnlocked?: number;
  historicalSalts?: string[];
}

export interface StorageEstimate {
  usage: number;
  quota: number;
  percentUsed: number;
  usageFormatted: string;
  quotaFormatted: string;
}
