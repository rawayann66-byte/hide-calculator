import React, { useState } from 'react';
import { Lock, Eye, EyeOff, X, ArrowRight, ShieldAlert } from 'lucide-react';
import { verifyPin, deriveVaultKey } from '../../services/crypto';
import { VaultConfig } from '../../types';
import { playTactileClick, playUnlockChime } from '../../services/audio';

interface SecretCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: VaultConfig;
  onUnlockVault: (pin: string, key: CryptoKey) => void;
  onOpenSetup: () => void;
}

export const SecretCodeModal: React.FC<SecretCodeModalProps> = ({
  isOpen,
  onClose,
  config,
  onUnlockVault,
  onOpenSetup,
}) => {
  const [pin, setPin] = useState('');
  const [showPin, setShowPin] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isVerifying, setIsVerifying] = useState(false);

  if (!isOpen) return null;

  const handleConfirm = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMessage(null);

    if (pin.length !== 4) {
      setErrorMessage('Please enter your 4-digit PIN.');
      return;
    }

    if (!config.isSetup) {
      onClose();
      onOpenSetup();
      return;
    }

    setIsVerifying(true);
    playTactileClick(config.hapticSound);

    try {
      const isValid = await verifyPin(pin, config.pinSalt, config.pinHash);
      if (isValid) {
        playUnlockChime(config.hapticSound);
        const key = await deriveVaultKey(pin, config.vaultSalt);
        onUnlockVault(pin, key);
        onClose();
      } else {
        setErrorMessage('Incorrect Code');
        setPin('');
      }
    } catch {
      setErrorMessage('Incorrect Code');
      setPin('');
    } finally {
      setIsVerifying(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-sm bg-zinc-950 border border-zinc-800 rounded-3xl p-6 shadow-2xl text-white">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-900 transition-colors"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 rounded-xl bg-zinc-900 border border-zinc-700 flex items-center justify-center text-white">
            <Lock className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white tracking-tight">Secret Vault Access</h2>
            <p className="text-xs text-zinc-400">Enter your 4-digit PIN to unlock</p>
          </div>
        </div>

        <form onSubmit={handleConfirm} className="space-y-4">
          <div>
            <div className="relative">
              <input
                type={showPin ? 'text' : 'password'}
                inputMode="numeric"
                pattern="[0-9]*"
                maxLength={4}
                value={pin}
                autoFocus
                onChange={(e) => {
                  const val = e.target.value.replace(/\D/g, '').slice(0, 4);
                  setPin(val);
                  if (errorMessage) setErrorMessage(null);
                }}
                placeholder="• • • •"
                className="w-full bg-zinc-900 border border-zinc-700 rounded-2xl px-4 py-3.5 text-white font-mono tracking-widest text-center text-2xl placeholder:text-zinc-600 focus:outline-none focus:border-white focus:ring-1 focus:ring-white transition-all"
              />
              <button
                type="button"
                onClick={() => setShowPin(!showPin)}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-white p-1"
                aria-label={showPin ? 'Hide PIN' : 'Show PIN'}
              >
                {showPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {errorMessage && (
            <div className="p-3 rounded-xl bg-red-950/80 border border-red-800 text-red-300 text-xs text-center font-bold flex items-center justify-center gap-2 animate-shake">
              <ShieldAlert className="w-4 h-4 text-red-400" />
              <span>{errorMessage}</span>
            </div>
          )}

          <div className="flex gap-2.5 pt-1">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-white text-xs font-semibold transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isVerifying || pin.length !== 4}
              className="flex-1 py-3 rounded-xl bg-white hover:bg-zinc-200 text-black text-xs font-bold flex items-center justify-center gap-1.5 transition-colors disabled:opacity-40 disabled:cursor-not-allowed shadow-md"
            >
              {isVerifying ? (
                'Verifying...'
              ) : (
                <>
                  Confirm <ArrowRight className="w-3.5 h-3.5" />
                </>
              )}
            </button>
          </div>
        </form>

        {!config.isSetup && (
          <div className="mt-4 pt-3 border-t border-zinc-900 text-center">
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenSetup();
              }}
              className="text-xs text-zinc-400 hover:text-white underline underline-offset-2"
            >
              No PIN set yet? Tap here to create PIN
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
