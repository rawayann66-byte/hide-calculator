import React, { useState } from 'react';
import { Plus, Search, Trash2, Edit3, Save, X, Lock, FileCode } from 'lucide-react';
import { DecryptedNote } from '../../types';
import { encryptText } from '../../services/crypto';
import { saveNote, deleteNote } from '../../services/db';

interface NotesTabProps {
  notes: DecryptedNote[];
  vaultKey: CryptoKey;
  onRefresh: () => Promise<void>;
}

export const NotesTab: React.FC<NotesTabProps> = ({
  notes,
  vaultKey,
  onRefresh,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeNote, setActiveNote] = useState<DecryptedNote | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editTitle, setEditTitle] = useState('');
  const [editContent, setEditContent] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  const filteredNotes = notes.filter(
    (n) =>
      n.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      n.content.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const startCreateNew = () => {
    setActiveNote(null);
    setEditTitle('');
    setEditContent('');
    setIsEditing(true);
  };

  const startEdit = (note: DecryptedNote) => {
    setActiveNote(note);
    setEditTitle(note.title);
    setEditContent(note.content);
    setIsEditing(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editTitle.trim() && !editContent.trim()) {
      alert('Please enter a title or note content.');
      return;
    }

    setIsSaving(true);
    try {
      const id = activeNote ? activeNote.id : `note_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      const title = editTitle.trim() || 'Untitled Note';
      const encryptedContent = await encryptText(editContent, vaultKey);

      await saveNote({
        id,
        title,
        encryptedContent,
        updatedAt: Date.now(),
      });

      await onRefresh();
      setIsEditing(false);
      setActiveNote({
        id,
        title,
        content: editContent,
        updatedAt: Date.now(),
      });
    } catch (err) {
      console.error('Note save error:', err);
      alert('Failed to encrypt and save note.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Delete this encrypted note?')) {
      await deleteNote(id);
      await onRefresh();
      if (activeNote?.id === id) {
        setActiveNote(null);
        setIsEditing(false);
      }
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-12 gap-4 min-h-[480px]">
      {/* Left Column: Note List */}
      <div className={`md:col-span-5 space-y-3 ${isEditing || activeNote ? 'hidden md:block' : 'block'}`}>
        <div className="flex items-center justify-between gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search notes..."
              className="w-full bg-zinc-900 border border-zinc-800 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder:text-zinc-500 focus:outline-none focus:border-zinc-600 transition-colors"
            />
          </div>

          <button
            onClick={startCreateNew}
            className="p-2 rounded-xl bg-white hover:bg-zinc-200 active:scale-95 text-black text-xs font-bold flex items-center justify-center transition-all shadow-md shrink-0"
            title="Create New Note"
            aria-label="New Note"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>

        {filteredNotes.length === 0 ? (
          <div className="text-center py-10 px-4 rounded-2xl bg-zinc-950/60 border border-zinc-900 text-zinc-500">
            <Lock className="w-8 h-8 mx-auto mb-2 text-zinc-600" />
            <p className="text-xs font-medium text-zinc-400">No secret notes yet</p>
            <p className="text-[11px] text-zinc-600 mt-1">Keep passwords, PINs, and sensitive thoughts secure</p>
          </div>
        ) : (
          <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
            {filteredNotes.map((note) => {
              const isSelected = activeNote?.id === note.id;
              return (
                <div
                  key={note.id}
                  onClick={() => {
                    setActiveNote(note);
                    setIsEditing(false);
                  }}
                  className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-zinc-900 border-zinc-600 text-white shadow-sm'
                      : 'bg-zinc-950/60 border-zinc-800/80 hover:border-zinc-700 text-zinc-300'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <h4 className="text-xs font-bold truncate text-white">{note.title}</h4>
                    <span className="text-[10px] text-zinc-500 font-mono shrink-0">
                      {new Date(note.updatedAt).toLocaleDateString()}
                    </span>
                  </div>
                  <p className="text-xs text-zinc-400 line-clamp-2 mt-1 whitespace-pre-wrap font-sans">
                    {note.content || '(Empty note)'}
                  </p>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Right Column: Note Reader / Editor */}
      <div className={`md:col-span-7 bg-zinc-950 border border-zinc-800/90 rounded-2xl p-4 flex flex-col ${
        !isEditing && !activeNote ? 'hidden md:flex items-center justify-center' : 'flex'
      }`}>
        {isEditing ? (
          <form onSubmit={handleSave} className="flex flex-col h-full space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-zinc-900">
              <span className="text-xs font-semibold text-zinc-400">
                {activeNote ? 'Edit Secret Note' : 'New Secret Note'}
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="px-3 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-300 text-xs font-medium transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="px-3.5 py-1.5 rounded-lg bg-white hover:bg-zinc-200 text-black text-xs font-bold flex items-center gap-1.5 transition-colors shadow-sm disabled:opacity-50"
                >
                  <Save className="w-3.5 h-3.5" />
                  {isSaving ? 'Encrypting...' : 'Save Note'}
                </button>
              </div>
            </div>

            <input
              type="text"
              value={editTitle}
              onChange={(e) => setEditTitle(e.target.value)}
              placeholder="Note Title (e.g. Master Passwords, Crypto Keys)"
              className="w-full bg-zinc-900/60 border border-zinc-800 rounded-xl px-3.5 py-2.5 text-sm font-semibold text-white placeholder:text-zinc-600 focus:outline-none focus:border-zinc-500"
            />

            <textarea
              value={editContent}
              onChange={(e) => setEditContent(e.target.value)}
              placeholder="Write your secret notes, recovery codes, or sensitive memos here..."
              rows={12}
              className="w-full flex-1 bg-zinc-900/40 border border-zinc-800 rounded-xl p-3.5 text-xs text-zinc-200 placeholder:text-zinc-600 focus:outline-none focus:border-zinc-500 font-mono resize-none leading-relaxed"
            />
          </form>
        ) : activeNote ? (
          <div className="flex flex-col h-full space-y-3">
            {/* Header with back button for mobile */}
            <div className="flex items-center justify-between pb-2 border-b border-zinc-900">
              <button
                onClick={() => setActiveNote(null)}
                className="md:hidden text-xs text-zinc-400 hover:text-white flex items-center gap-1"
              >
                ← Back
              </button>
              <div className="text-[10px] text-zinc-500 font-mono ml-auto mr-3">
                Updated {new Date(activeNote.updatedAt).toLocaleString()}
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => startEdit(activeNote)}
                  className="p-1.5 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-900 transition-colors"
                  title="Edit Note"
                  aria-label="Edit"
                >
                  <Edit3 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDelete(activeNote.id)}
                  className="p-1.5 text-zinc-500 hover:text-red-400 rounded-lg hover:bg-zinc-900 transition-colors"
                  title="Delete Note"
                  aria-label="Delete"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            <h3 className="text-base font-bold text-white tracking-tight">{activeNote.title}</h3>

            <div className="flex-1 bg-zinc-900/40 border border-zinc-900 rounded-xl p-4 overflow-y-auto">
              <pre className="text-xs text-zinc-300 font-mono whitespace-pre-wrap leading-relaxed select-text">
                {activeNote.content}
              </pre>
            </div>
          </div>
        ) : (
          <div className="text-center py-16 text-zinc-600">
            <FileCode className="w-10 h-10 mx-auto mb-2 text-zinc-700" />
            <p className="text-xs font-medium text-zinc-400">Select a note to read or create a new one</p>
          </div>
        )}
      </div>
    </div>
  );
};
