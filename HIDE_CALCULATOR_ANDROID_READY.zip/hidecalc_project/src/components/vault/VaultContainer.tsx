import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  Image as ImageIcon,
  Film,
  FileText,
  FileCode,
  Settings,
  Lock,
  LogOut,
  Shield,
  Loader2,
  HardDrive,
  EyeOff,
  Calculator as CalcIcon,
} from 'lucide-react';
import {
  VaultConfig,
  VaultFileItem,
  DecryptedFileItem,
  VaultNote,
  DecryptedNote,
} from '../../types';
import { getAllFiles, getAllNotes, deleteFile, saveFile, saveNote } from '../../services/db';
import {
  decryptData,
  decryptText,
  encryptData,
  encryptText,
  deriveVaultKey,
  tryDecryptWithCandidates,
} from '../../services/crypto';
import { PhotosTab } from './PhotosTab';
import { VideosTab } from './VideosTab';
import { FilesTab } from './FilesTab';
import { NotesTab } from './NotesTab';
import { SettingsTab } from './SettingsTab';
import { MediaViewerModal } from './MediaViewerModal';

interface VaultContainerProps {
  config: VaultConfig;
  currentPin: string;
  vaultKey: CryptoKey;
  onConfigUpdated: (newConfig: VaultConfig) => void;
  onPinChanged: (newPin: string, newKey: CryptoKey) => void;
  onLockVault: () => void;
  onPanicLock: () => void;
  onSwitchToCalculator?: () => void;
}

type TabType = 'photos' | 'videos' | 'files' | 'notes' | 'settings';

export const VaultContainer: React.FC<VaultContainerProps> = ({
  config,
  currentPin,
  vaultKey,
  onConfigUpdated,
  onPinChanged,
  onLockVault,
  onPanicLock,
  onSwitchToCalculator,
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('photos');
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Decrypted items cache
  const [photos, setPhotos] = useState<DecryptedFileItem[]>([]);
  const [videos, setVideos] = useState<DecryptedFileItem[]>([]);
  const [files, setFiles] = useState<DecryptedFileItem[]>([]);
  const [notes, setNotes] = useState<DecryptedNote[]>([]);
  const [unrecoveredFiles, setUnrecoveredFiles] = useState<VaultFileItem[]>([]);

  // Selected media for full preview modal
  const [selectedMedia, setSelectedMedia] = useState<DecryptedFileItem | null>(null);

  // Store active Object URLs so we can revoke them cleanly
  const activeBlobUrlsRef = useRef<Set<string>>(new Set());

  // Cleanup all allocated Object URLs
  const cleanupBlobUrls = useCallback(() => {
    activeBlobUrlsRef.current.forEach((url) => {
      URL.revokeObjectURL(url);
    });
    activeBlobUrlsRef.current.clear();
  }, []);

  // Decrypt and load all files & notes from IndexedDB
  const loadVaultData = useCallback(async () => {
    setIsLoading(true);
    cleanupBlobUrls();

    try {
      const rawFiles = await getAllFiles();
      const rawNotes = await getAllNotes();

      const decryptedPhotos: DecryptedFileItem[] = [];
      const decryptedVideos: DecryptedFileItem[] = [];
      const decryptedDocs: DecryptedFileItem[] = [];
      const failedItems: VaultFileItem[] = [];

      const candidateSalts = [
        config.vaultSalt,
        ...(config.historicalSalts || []),
      ].filter(Boolean);

      const candidatePins = [
        currentPin,
        '1234',
        '1984',
        '0000',
        '1111',
        '2580',
        '4321',
        '9999',
        '1212',
        '7777',
        '8888',
        '1357',
        '2468',
      ];

      for (const item of rawFiles) {
        let decryptedBuffer: ArrayBuffer | null = null;

        // 1. Try active vaultKey
        try {
          decryptedBuffer = await decryptData(item.encryptedData, vaultKey);
        } catch {
          // 2. Try candidate PINs and historical salts to auto-heal
          const recovered = await tryDecryptWithCandidates(
            item.encryptedData,
            candidatePins,
            candidateSalts
          );

          if (recovered) {
            decryptedBuffer = recovered.decrypted;
            // Auto-heal: Re-encrypt with active vaultKey so future decryptions are immediate
            try {
              const reEncrypted = await encryptData(recovered.decrypted, vaultKey);
              await saveFile({ ...item, encryptedData: reEncrypted });
            } catch {
              // ignore
            }
          }
        }

        if (decryptedBuffer) {
          const blob = new Blob([decryptedBuffer], { type: item.mimeType });
          const blobUrl = URL.createObjectURL(blob);
          activeBlobUrlsRef.current.add(blobUrl);

          const decItem: DecryptedFileItem = {
            id: item.id,
            name: item.name,
            type: item.type,
            mimeType: item.mimeType,
            size: item.size,
            createdAt: item.createdAt,
            blobUrl,
            notes: item.notes,
            blob,
          };

          if (item.type === 'photo') decryptedPhotos.push(decItem);
          else if (item.type === 'video') decryptedVideos.push(decItem);
          else decryptedDocs.push(decItem);
        } else {
          // Unrecovered item: record gracefully without console.error
          failedItems.push(item);
        }
      }

      const decryptedNotesList: DecryptedNote[] = [];
      for (const note of rawNotes) {
        let content: string | null = null;
        try {
          content = await decryptText(note.encryptedContent, vaultKey);
        } catch {
          const recovered = await tryDecryptWithCandidates(
            note.encryptedContent,
            candidatePins,
            candidateSalts
          );
          if (recovered) {
            const dec = new TextDecoder();
            content = dec.decode(recovered.decrypted);
            try {
              const reEncrypted = await encryptText(content, vaultKey);
              await saveNote({ ...note, encryptedContent: reEncrypted });
            } catch {
              // ignore
            }
          }
        }

        if (content !== null) {
          decryptedNotesList.push({
            id: note.id,
            title: note.title,
            content,
            updatedAt: note.updatedAt,
          });
        }
      }

      setPhotos(decryptedPhotos);
      setVideos(decryptedVideos);
      setFiles(decryptedDocs);
      setNotes(decryptedNotesList);
      setUnrecoveredFiles(failedItems);
    } catch (err) {
      console.warn('Vault data loading notice:', err);
    } finally {
      setIsLoading(false);
    }
  }, [vaultKey, currentPin, config.vaultSalt, config.historicalSalts, cleanupBlobUrls]);

  // Initial load
  useEffect(() => {
    loadVaultData();
    return () => {
      cleanupBlobUrls();
    };
  }, [loadVaultData, cleanupBlobUrls]);

  // Auto-lock on inactivity timer
  useEffect(() => {
    if (config.autoLockDelay <= 0) return;

    let timeoutId: NodeJS.Timeout;
    const resetTimer = () => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        onLockVault();
      }, config.autoLockDelay * 1000);
    };

    resetTimer();

    const events = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart'];
    events.forEach((evt) => window.addEventListener(evt, resetTimer, { passive: true }));

    return () => {
      clearTimeout(timeoutId);
      events.forEach((evt) => window.removeEventListener(evt, resetTimer));
    };
  }, [config.autoLockDelay, onLockVault]);

  // Lock on window blur or tab switch
  useEffect(() => {
    if (!config.lockOnBlur) return;

    const handleVisibilityChange = () => {
      if (document.hidden) {
        onLockVault();
      }
    };

    const handleBlur = () => {
      onLockVault();
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('blur', handleBlur);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('blur', handleBlur);
    };
  }, [config.lockOnBlur, onLockVault]);

  // Delete single file handler
  const handleDeleteFile = async (id: string) => {
    await deleteFile(id);
    await loadVaultData();
    if (selectedMedia?.id === id) {
      setSelectedMedia(null);
    }
  };

  const handleRecoverItemWithPin = async (item: VaultFileItem) => {
    const enteredPin = window.prompt(`Enter the PIN used when "${item.name}" was added (e.g. 1234):`);
    if (!enteredPin || enteredPin.length !== 4) return;

    const candidateSalts = [
      config.vaultSalt,
      ...(config.historicalSalts || []),
    ].filter(Boolean);

    const recovered = await tryDecryptWithCandidates(item.encryptedData, [enteredPin], candidateSalts);
    if (recovered) {
      const reEncrypted = await encryptData(recovered.decrypted, vaultKey);
      await saveFile({ ...item, encryptedData: reEncrypted });
      alert(`Successfully unlocked "${item.name}" and re-encrypted with your current PIN!`);
      await loadVaultData();
    } else {
      alert(`Could not decrypt "${item.name}" with PIN "${enteredPin}". Please check the PIN.`);
    }
  };

  const handleDeleteFailedItem = async (id: string, name: string) => {
    if (window.confirm(`Remove unrecovered item "${name}" from vault?`)) {
      await deleteFile(id);
      await loadVaultData();
    }
  };

  const currentTabItems =
    activeTab === 'photos' ? photos : activeTab === 'videos' ? videos : files;

  return (
    <div className="w-full min-h-[90vh] flex flex-col bg-black text-white select-none">
      {/* Top Navigation Bar: One-Row Contract */}
      <header className="sticky top-0 z-30 bg-zinc-950/90 backdrop-blur-md border-b border-zinc-800/80 px-4 sm:px-6 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          {/* Brand Zone */}
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-white text-black flex items-center justify-center font-bold text-xs shadow-md">
              <Lock className="w-4 h-4" />
            </div>
            <div>
              <span className="text-sm font-bold tracking-tight text-white block">HIDE VAULT</span>
              <span className="text-[10px] text-zinc-500 font-mono hidden sm:block">
                AES-256-GCM · Client Encrypted
              </span>
            </div>
            {onSwitchToCalculator && (
              <button
                onClick={onSwitchToCalculator}
                className="ml-2 px-2.5 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-white border border-zinc-800 text-xs font-medium flex items-center gap-1.5 transition-colors shadow-sm"
                title="Switch to Calculator"
              >
                <CalcIcon className="w-3.5 h-3.5 text-zinc-400" />
                <span>Calculator</span>
              </button>
            )}
          </div>

          {/* Navigation Tabs (Desktop & Tablet) */}
          <nav className="hidden md:flex items-center gap-1 bg-zinc-900/80 p-1 rounded-xl border border-zinc-800">
            <button
              onClick={() => setActiveTab('photos')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap ${
                activeTab === 'photos'
                  ? 'bg-white text-black shadow-sm'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              <ImageIcon className="w-3.5 h-3.5" />
              Photos ({photos.length})
            </button>
            <button
              onClick={() => setActiveTab('videos')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap ${
                activeTab === 'videos'
                  ? 'bg-white text-black shadow-sm'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              <Film className="w-3.5 h-3.5" />
              Videos ({videos.length})
            </button>
            <button
              onClick={() => setActiveTab('files')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap ${
                activeTab === 'files'
                  ? 'bg-white text-black shadow-sm'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              Files ({files.length})
            </button>
            <button
              onClick={() => setActiveTab('notes')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap ${
                activeTab === 'notes'
                  ? 'bg-white text-black shadow-sm'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              <FileCode className="w-3.5 h-3.5" />
              Notes ({notes.length})
            </button>
            <button
              onClick={() => setActiveTab('settings')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap ${
                activeTab === 'settings'
                  ? 'bg-white text-black shadow-sm'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              <Settings className="w-3.5 h-3.5" />
              Settings
            </button>
          </nav>

          {/* Primary Quick Panic Lock CTA */}
          <div className="flex items-center gap-2">
            <button
              onClick={onPanicLock}
              className="px-3 sm:px-4 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-white border border-zinc-700/80 text-xs font-semibold flex items-center gap-1.5 transition-all shadow-sm active:scale-95"
              title="Instantly lock and switch back to calculator"
            >
              <EyeOff className="w-3.5 h-3.5 text-zinc-400" />
              <span className="hidden sm:inline">Panic Lock</span>
            </button>
            <button
              onClick={onLockVault}
              className="p-2 sm:px-3 sm:py-2 rounded-xl bg-white hover:bg-zinc-200 text-black text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm active:scale-95"
              title="Lock Vault"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Lock</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Vault Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 pb-24 md:pb-8">
        {isLoading ? (
          <div className="flex flex-col items-center justify-center py-24 space-y-3 text-zinc-500">
            <Loader2 className="w-8 h-8 animate-spin text-white" />
            <p className="text-xs font-mono">Decrypting vault contents with AES-256-GCM...</p>
          </div>
        ) : (
          <>
            {unrecoveredFiles.length > 0 && (
              <div className="mb-4 p-4 rounded-2xl bg-zinc-950 border border-zinc-800 text-xs text-zinc-300 space-y-2.5 shadow-sm">
                <div className="flex items-center gap-2">
                  <Shield className="w-4 h-4 text-zinc-400 shrink-0" />
                  <span className="font-semibold text-white">
                    {unrecoveredFiles.length} file(s) require previous PIN to unlock (may have been added before PIN change)
                  </span>
                </div>
                <div className="divide-y divide-zinc-900">
                  {unrecoveredFiles.map((item) => (
                    <div key={item.id} className="py-2.5 flex items-center justify-between gap-3">
                      <span className="truncate max-w-[220px] text-zinc-300 font-mono text-[11px] font-medium">
                        {item.name}
                      </span>
                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          onClick={() => handleRecoverItemWithPin(item)}
                          className="px-3 py-1.5 rounded-xl bg-white hover:bg-zinc-200 text-black text-xs font-bold transition-colors shadow-sm"
                        >
                          Unlock with Old PIN
                        </button>
                        <button
                          onClick={() => handleDeleteFailedItem(item.id, item.name)}
                          className="px-3 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-red-400 text-xs font-medium transition-colors border border-zinc-800"
                        >
                          Remove
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'photos' && (
              <PhotosTab
                photos={photos}
                vaultKey={vaultKey}
                onRefresh={loadVaultData}
                onSelectPhoto={(photo) => setSelectedMedia(photo)}
                onDeletePhoto={handleDeleteFile}
              />
            )}

            {activeTab === 'videos' && (
              <VideosTab
                videos={videos}
                vaultKey={vaultKey}
                onRefresh={loadVaultData}
                onSelectVideo={(video) => setSelectedMedia(video)}
                onDeleteVideo={handleDeleteFile}
              />
            )}

            {activeTab === 'files' && (
              <FilesTab
                files={files}
                vaultKey={vaultKey}
                onRefresh={loadVaultData}
                onSelectFile={(file) => setSelectedMedia(file)}
                onDeleteFile={handleDeleteFile}
              />
            )}

            {activeTab === 'notes' && (
              <NotesTab
                notes={notes}
                vaultKey={vaultKey}
                onRefresh={loadVaultData}
              />
            )}

            {activeTab === 'settings' && (
              <SettingsTab
                config={config}
                currentPin={currentPin}
                vaultKey={vaultKey}
                photos={photos}
                videos={videos}
                files={files}
                notes={notes}
                onConfigUpdated={onConfigUpdated}
                onPinChanged={onPinChanged}
                onRefreshAll={loadVaultData}
                onLockVault={onLockVault}
              />
            )}
          </>
        )}
      </main>

      {/* Mobile Fixed Bottom Navigation Bar (Pattern 1 from Mobile Domain) */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-zinc-950/95 backdrop-blur-lg border-t border-zinc-800 grid grid-cols-5 h-16 items-center px-1">
        <button
          onClick={() => setActiveTab('photos')}
          className={`flex flex-col items-center justify-center h-full transition-colors ${
            activeTab === 'photos' ? 'text-white' : 'text-zinc-500 hover:text-zinc-300'
          }`}
        >
          <ImageIcon className="w-5 h-5" />
          <span className="text-[10px] font-medium tracking-tight mt-1">Photos</span>
        </button>

        <button
          onClick={() => setActiveTab('videos')}
          className={`flex flex-col items-center justify-center h-full transition-colors ${
            activeTab === 'videos' ? 'text-white' : 'text-zinc-500 hover:text-zinc-300'
          }`}
        >
          <Film className="w-5 h-5" />
          <span className="text-[10px] font-medium tracking-tight mt-1">Videos</span>
        </button>

        <button
          onClick={() => setActiveTab('files')}
          className={`flex flex-col items-center justify-center h-full transition-colors ${
            activeTab === 'files' ? 'text-white' : 'text-zinc-500 hover:text-zinc-300'
          }`}
        >
          <FileText className="w-5 h-5" />
          <span className="text-[10px] font-medium tracking-tight mt-1">Files</span>
        </button>

        <button
          onClick={() => setActiveTab('notes')}
          className={`flex flex-col items-center justify-center h-full transition-colors ${
            activeTab === 'notes' ? 'text-white' : 'text-zinc-500 hover:text-zinc-300'
          }`}
        >
          <FileCode className="w-5 h-5" />
          <span className="text-[10px] font-medium tracking-tight mt-1">Notes</span>
        </button>

        <button
          onClick={() => setActiveTab('settings')}
          className={`flex flex-col items-center justify-center h-full transition-colors ${
            activeTab === 'settings' ? 'text-white' : 'text-zinc-500 hover:text-zinc-300'
          }`}
        >
          <Settings className="w-5 h-5" />
          <span className="text-[10px] font-medium tracking-tight mt-1">Settings</span>
        </button>
      </nav>

      {/* Fullscreen Media Viewer Modal */}
      {selectedMedia && (
        <MediaViewerModal
          item={selectedMedia}
          allItems={currentTabItems}
          onClose={() => setSelectedMedia(null)}
          onDelete={handleDeleteFile}
          onNavigate={(nextItem) => setSelectedMedia(nextItem)}
        />
      )}
    </div>
  );
};
