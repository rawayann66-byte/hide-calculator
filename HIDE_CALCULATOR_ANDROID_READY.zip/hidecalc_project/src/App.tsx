/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { PinLockScreen } from './components/lock/PinLockScreen';
import { Calculator } from './components/calculator/Calculator';
import { VaultContainer } from './components/vault/VaultContainer';
import { FakeCrashScreen } from './components/vault/FakeCrashScreen';
import { VaultConfig } from './types';
import { getConfig } from './services/db';
import { SecretCodeModal } from './components/calculator/SecretCodeModal';
import { Lock, LogOut, ShieldCheck, FolderLock, Calculator as CalcIcon } from 'lucide-react';

export default function App() {
  const [config, setConfig] = useState<VaultConfig | null>(null);
  const [isUnlocked, setIsUnlocked] = useState<boolean>(false);
  const [activeView, setActiveView] = useState<'calculator' | 'vault'>('calculator');
  const [currentPin, setCurrentPin] = useState<string>('');
  const [vaultKey, setVaultKey] = useState<CryptoKey | null>(null);
  const [isFakeCrash, setIsFakeCrash] = useState<boolean>(false);
  const [showVaultAuthModal, setShowVaultAuthModal] = useState<boolean>(false);

  // Load config on startup
  useEffect(() => {
    getConfig().then((loadedConfig) => {
      setConfig(loadedConfig);
    });
  }, []);

  // Unlock callback when correct PIN is entered on Opening Screen
  const handleUnlock = useCallback((pin: string, key: CryptoKey) => {
    setCurrentPin(pin);
    setVaultKey(key);
    setIsUnlocked(true);
    setActiveView('calculator'); // Requirement: Correct PIN opens the main Calculator screen
    setIsFakeCrash(false);
  }, []);

  // Lock callback (relocks to opening PIN lock screen and wipes key)
  const handleLockApp = useCallback(() => {
    setVaultKey(null);
    setCurrentPin('');
    setIsUnlocked(false);
    setActiveView('calculator');
    setIsFakeCrash(false);
  }, []);

  // Handle clicking the Private Vault tab (protected by PIN authentication)
  const handleOpenVaultTab = useCallback(() => {
    if (activeView === 'vault') return;
    setShowVaultAuthModal(true);
  }, [activeView]);

  // Panic lock
  const handlePanicLock = useCallback(() => {
    setVaultKey(null);
    setCurrentPin('');
    setIsUnlocked(false);
    if (config?.panicAction === 'fake_crash') {
      setIsFakeCrash(true);
    }
  }, [config?.panicAction]);

  if (!config) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center text-white font-mono text-sm">
        Initializing secure environment...
      </div>
    );
  }

  // 1. Fake Crash Decoy Screen if triggered
  if (isFakeCrash) {
    return <FakeCrashScreen onRecover={() => setIsFakeCrash(false)} />;
  }

  // 2. OPENING SCREEN: Always show full-screen PIN screen when locked or on refresh
  if (!isUnlocked || !vaultKey) {
    return (
      <PinLockScreen
        config={config}
        onConfigUpdated={(newCfg) => setConfig(newCfg)}
        onUnlock={handleUnlock}
      />
    );
  }

  // 3. MAIN APP (Unlocked via successful PIN verification)
  return (
    <div className="min-h-screen bg-black text-white flex flex-col justify-between selection:bg-zinc-700 selection:text-white">
      {/* Top Main Navigation Bar */}
      <header className="sticky top-0 z-40 bg-zinc-950/95 backdrop-blur-md border-b border-zinc-800/80 px-4 sm:px-6 py-2.5">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
          {/* Brand Wordmark */}
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-white text-black flex items-center justify-center font-bold shadow">
              <Lock className="w-3.5 h-3.5" />
            </div>
            <span className="font-mono font-bold tracking-tight text-white text-sm">
              HIDE CALCULATOR
            </span>
          </div>

          {/* View Switcher: Calculator <-> Private Vault (Protected by PIN) */}
          <div className="flex items-center p-1 bg-zinc-900 border border-zinc-800 rounded-xl">
            <button
              onClick={() => setActiveView('calculator')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all whitespace-nowrap ${
                activeView === 'calculator'
                  ? 'bg-white text-black shadow-sm'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              <CalcIcon className="w-3.5 h-3.5" />
              Calculator
            </button>
            <button
              onClick={handleOpenVaultTab}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all whitespace-nowrap ${
                activeView === 'vault'
                  ? 'bg-white text-black shadow-sm'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              <FolderLock className="w-3.5 h-3.5" />
              Private Vault
            </button>
          </div>

          {/* Lock Action Button */}
          <button
            onClick={handleLockApp}
            className="px-3 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-700/80 text-zinc-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition-all active:scale-95 shadow-sm"
            title="Lock app and return to PIN screen"
          >
            <LogOut className="w-3.5 h-3.5 text-zinc-400" />
            <span className="hidden sm:inline">Lock</span>
          </button>
        </div>
      </header>

      {/* Main App Content View */}
      <main className="flex-1 flex flex-col justify-center">
        {activeView === 'calculator' ? (
          <div className="flex-1 flex flex-col justify-center items-center px-4 py-6 sm:py-10 max-w-lg mx-auto w-full">
            {/* Calculator Component */}
            <Calculator
              config={config}
              onConfigUpdated={(newCfg) => setConfig(newCfg)}
              onUnlockVault={(pin, key) => {
                setCurrentPin(pin);
                setVaultKey(key);
                setActiveView('vault');
              }}
              onFakeCrash={() => setIsFakeCrash(true)}
            />
          </div>
        ) : (
          <VaultContainer
            config={config}
            currentPin={currentPin}
            vaultKey={vaultKey}
            onConfigUpdated={(newCfg) => setConfig(newCfg)}
            onPinChanged={(newPin, newKey) => {
              setCurrentPin(newPin);
              setVaultKey(newKey);
            }}
            onLockVault={handleLockApp}
            onPanicLock={handlePanicLock}
            onSwitchToCalculator={() => setActiveView('calculator')}
          />
        )}
      </main>

      {/* PIN Authentication Modal for Private Vault Tab */}
      <SecretCodeModal
        isOpen={showVaultAuthModal}
        onClose={() => setShowVaultAuthModal(false)}
        config={config}
        onUnlockVault={(pin, key) => {
          setCurrentPin(pin);
          setVaultKey(key);
          setActiveView('vault');
          setShowVaultAuthModal(false);
        }}
        onOpenSetup={() => setShowVaultAuthModal(false)}
      />
    </div>
  );
}
