import React, { useState, useRef, useTransition } from 'react';
import { Upload, FileText, Download, Trash2, Search, Plus, Eye, FileSpreadsheet, FileArchive, FileCode, File } from 'lucide-react';
import { DecryptedFileItem } from '../../types';
import { encryptData } from '../../services/crypto';
import { saveFile } from '../../services/db';

interface FilesTabProps {
  files: DecryptedFileItem[];
  vaultKey: CryptoKey;
  onRefresh: () => Promise<void>;
  onSelectFile: (item: DecryptedFileItem) => void;
  onDeleteFile: (id: string) => Promise<void>;
}

export const FilesTab: React.FC<FilesTabProps> = ({
  files,
  vaultKey,
  onRefresh,
  onSelectFile,
  onDeleteFile,
}) => {
  const [, startTransition] = useTransition();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isDragging, setIsDragging] = useState(false);

  const filteredFiles = files.filter((f) =>
    f.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleFileUpload = async (uploadedFiles: FileList | File[]) => {
    const list = Array.from(uploadedFiles);
    if (list.length === 0) return;

    setIsUploading(true);
    try {
      for (const file of list) {
        const arrayBuf = await file.arrayBuffer();

        // Encrypt with AES-256-GCM
        const encryptedData = await encryptData(arrayBuf, vaultKey);

        const newVaultItem = {
          id: `file_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
          name: file.name,
          type: 'file' as const,
          mimeType: file.type || 'application/octet-stream',
          size: file.size,
          createdAt: Date.now(),
          encryptedData,
        };

        await saveFile(newVaultItem);
      }
      await onRefresh();
    } catch (err) {
      console.error('File encryption error:', err);
      alert('Failed to encrypt file. Check browser storage limits.');
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const getFileIcon = (mime: string, name: string) => {
    if (mime.includes('pdf') || name.endsWith('.pdf')) {
      return <FileText className="w-5 h-5 text-red-400" />;
    }
    if (mime.includes('sheet') || mime.includes('csv') || name.endsWith('.csv') || name.endsWith('.xlsx')) {
      return <FileSpreadsheet className="w-5 h-5 text-emerald-400" />;
    }
    if (mime.includes('zip') || mime.includes('rar') || mime.includes('tar') || name.endsWith('.zip')) {
      return <FileArchive className="w-5 h-5 text-amber-400" />;
    }
    if (mime.includes('json') || mime.includes('javascript') || mime.includes('html') || name.endsWith('.json')) {
      return <FileCode className="w-5 h-5 text-blue-400" />;
    }
    return <File className="w-5 h-5 text-zinc-300" />;
  };

  const formatSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  const handleDownload = (item: DecryptedFileItem, e: React.MouseEvent) => {
    e.stopPropagation();
    const a = document.createElement('a');
    a.href = item.blobUrl;
    a.download = item.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="space-y-4">
      {/* Search and Action Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search documents and PDFs..."
            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl pl-9 pr-4 py-2 text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:border-zinc-600 transition-colors"
          />
        </div>

        <button
          onClick={() => fileInputRef.current?.click()}
          disabled={isUploading}
          className="px-4 py-2 rounded-xl bg-white hover:bg-zinc-200 active:scale-95 text-black text-xs font-bold flex items-center gap-1.5 transition-all shadow-md shrink-0 disabled:opacity-50"
        >
          <Plus className="w-4 h-4" />
          Import Documents
        </button>
        <input
          ref={fileInputRef}
          type="file"
          multiple
          className="hidden"
          onChange={(e) => {
            if (e.target.files) {
              const files = e.target.files;
              startTransition(() => {
                handleFileUpload(files);
              });
            }
          }}
        />
      </div>

      {/* Drag & Drop Area */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={(e) => {
          e.preventDefault();
          setIsDragging(false);
          if (e.dataTransfer.files) {
            startTransition(() => {
              handleFileUpload(e.dataTransfer.files);
            });
          }
        }}
        className={`border-2 border-dashed rounded-2xl p-6 text-center transition-all ${
          isDragging
            ? 'border-white bg-zinc-900'
            : 'border-zinc-800 hover:border-zinc-700 bg-zinc-950/60'
        }`}
      >
        <div className="w-12 h-12 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center mx-auto text-zinc-400 mb-2">
          <Upload className="w-6 h-6 text-zinc-300" />
        </div>
        <p className="text-sm font-medium text-white mb-1">
          Drop secret PDFs, docs, or files here
        </p>
        <p className="text-xs text-zinc-500">
          Encrypted with AES-256-GCM. Stored purely inside your local browser database.
        </p>
      </div>

      {/* Files List / Table */}
      {filteredFiles.length === 0 ? (
        <div className="text-center py-12 px-4 rounded-2xl bg-zinc-950/40 border border-zinc-900">
          <div className="w-14 h-14 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center mx-auto text-zinc-500 mb-3">
            <FileText className="w-7 h-7" />
          </div>
          <h3 className="text-sm font-semibold text-zinc-300 mb-1">No Secret Documents Stored</h3>
          <p className="text-xs text-zinc-500 max-w-sm mx-auto mb-4">
            Protect sensitive contracts, statements, IDs, and tax documents in your private encrypted vault.
          </p>
        </div>
      ) : (
        <div className="bg-zinc-950 border border-zinc-800/80 rounded-2xl overflow-hidden divide-y divide-zinc-900">
          {filteredFiles.map((file) => (
            <div
              key={file.id}
              onClick={() => onSelectFile(file)}
              className="flex items-center justify-between p-3.5 sm:p-4 hover:bg-zinc-900/60 transition-colors cursor-pointer group"
            >
              <div className="flex items-center gap-3.5 overflow-hidden pr-3">
                <div className="w-10 h-10 rounded-xl bg-zinc-900 border border-zinc-800 flex items-center justify-center shrink-0 group-hover:border-zinc-700 transition-colors">
                  {getFileIcon(file.mimeType, file.name)}
                </div>
                <div className="overflow-hidden">
                  <h4 className="text-sm font-medium text-white truncate group-hover:text-zinc-200">
                    {file.name}
                  </h4>
                  <div className="flex items-center gap-2 text-xs text-zinc-500 font-mono mt-0.5">
                    <span>{formatSize(file.size)}</span>
                    <span>·</span>
                    <span>{new Date(file.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-1 shrink-0">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectFile(file);
                  }}
                  className="p-2 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800 transition-colors"
                  title="Preview Document"
                  aria-label="Preview"
                >
                  <Eye className="w-4 h-4" />
                </button>
                <button
                  onClick={(e) => handleDownload(file, e)}
                  className="p-2 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800 transition-colors"
                  title="Download File"
                  aria-label="Download"
                >
                  <Download className="w-4 h-4" />
                </button>
                <button
                  onClick={async (e) => {
                    e.stopPropagation();
                    if (window.confirm(`Delete "${file.name}"?`)) {
                      await onDeleteFile(file.id);
                    }
                  }}
                  className="p-2 text-zinc-500 hover:text-red-400 rounded-lg hover:bg-zinc-800 transition-colors"
                  title="Delete File"
                  aria-label="Delete"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
