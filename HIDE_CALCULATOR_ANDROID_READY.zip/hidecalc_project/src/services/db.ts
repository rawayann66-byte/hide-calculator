import { VaultConfig, VaultFileItem, VaultNote, StorageEstimate } from '../types';

const DB_NAME = 'HideCalculatorVaultDB';
const DB_VERSION = 1;

let dbPromise: Promise<IDBDatabase> | null = null;

export function getDb(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;

  dbPromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;

      if (!db.objectStoreNames.contains('config')) {
        db.createObjectStore('config');
      }

      if (!db.objectStoreNames.contains('files')) {
        const fileStore = db.createObjectStore('files', { keyPath: 'id' });
        fileStore.createIndex('type', 'type', { unique: false });
        fileStore.createIndex('createdAt', 'createdAt', { unique: false });
      }

      if (!db.objectStoreNames.contains('notes')) {
        const notesStore = db.createObjectStore('notes', { keyPath: 'id' });
        notesStore.createIndex('updatedAt', 'updatedAt', { unique: false });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => {
      dbPromise = null;
      reject(request.error);
    };
  });

  return dbPromise;
}

const DEFAULT_CONFIG: VaultConfig = {
  isSetup: false,
  pinSalt: '',
  pinHash: '',
  vaultSalt: '',
  autoLockDelay: 300, // 5 minutes default
  lockOnBlur: true,
  hapticSound: true,
  panicAction: 'calculator',
};

const LOCAL_STORAGE_KEY = 'hide_calc_vault_config';

export async function getConfig(): Promise<VaultConfig> {
  // Check localStorage cache first for fast initial state
  let localCached: Partial<VaultConfig> | null = null;
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (raw) localCached = JSON.parse(raw);
  } catch {
    // ignore
  }

  try {
    const db = await getDb();
    return new Promise((resolve) => {
      const tx = db.transaction('config', 'readonly');
      const store = tx.objectStore('config');
      const req = store.get('vault_config');
      req.onsuccess = () => {
        if (req.result && req.result.pinHash) {
          try {
            localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(req.result));
          } catch {
            // ignore
          }
          resolve({ ...DEFAULT_CONFIG, ...req.result, isSetup: true });
        } else if (localCached && localCached.pinHash) {
          // Restore to IndexedDB if present in localStorage
          saveConfig(localCached).catch(() => {});
          resolve({ ...DEFAULT_CONFIG, ...localCached, isSetup: true });
        } else {
          resolve(DEFAULT_CONFIG);
        }
      };
      req.onerror = () => {
        if (localCached && localCached.pinHash) {
          resolve({ ...DEFAULT_CONFIG, ...localCached, isSetup: true });
        } else {
          resolve(DEFAULT_CONFIG);
        }
      };
    });
  } catch {
    if (localCached && localCached.pinHash) {
      return { ...DEFAULT_CONFIG, ...localCached, isSetup: true };
    }
    return DEFAULT_CONFIG;
  }
}

export async function saveConfig(config: Partial<VaultConfig>): Promise<VaultConfig> {
  const current = await getConfig();
  const updated: VaultConfig = { ...current, ...config };

  // Dual persist to localStorage
  try {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(updated));
  } catch {
    // ignore
  }

  const db = await getDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('config', 'readwrite');
    const store = tx.objectStore('config');
    const req = store.put(updated, 'vault_config');
    req.onsuccess = () => resolve(updated);
    req.onerror = () => reject(req.error);
  });
}

// Reset PIN configuration only without deleting any stored vault files
export async function resetPinConfigOnly(): Promise<VaultConfig> {
  try {
    localStorage.removeItem(LOCAL_STORAGE_KEY);
  } catch {
    // ignore
  }

  const db = await getDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('config', 'readwrite');
    const store = tx.objectStore('config');
    const req = store.delete('vault_config');
    req.onsuccess = () => resolve(DEFAULT_CONFIG);
    req.onerror = () => reject(req.error);
  });
}

// File Operations
export async function getAllFiles(): Promise<VaultFileItem[]> {
  const db = await getDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('files', 'readonly');
    const store = tx.objectStore('files');
    const req = store.getAll();
    req.onsuccess = () => {
      const items: VaultFileItem[] = req.result || [];
      // Sort newest first
      items.sort((a, b) => b.createdAt - a.createdAt);
      resolve(items);
    };
    req.onerror = () => reject(req.error);
  });
}

export async function getFileById(id: string): Promise<VaultFileItem | null> {
  const db = await getDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('files', 'readonly');
    const store = tx.objectStore('files');
    const req = store.get(id);
    req.onsuccess = () => resolve(req.result || null);
    req.onerror = () => reject(req.error);
  });
}

export async function saveFile(fileItem: VaultFileItem): Promise<void> {
  const db = await getDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('files', 'readwrite');
    const store = tx.objectStore('files');
    const req = store.put(fileItem);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export async function deleteFile(id: string): Promise<void> {
  const db = await getDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('files', 'readwrite');
    const store = tx.objectStore('files');
    const req = store.delete(id);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

// Notes Operations
export async function getAllNotes(): Promise<VaultNote[]> {
  const db = await getDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('notes', 'readonly');
    const store = tx.objectStore('notes');
    const req = store.getAll();
    req.onsuccess = () => {
      const items: VaultNote[] = req.result || [];
      items.sort((a, b) => b.updatedAt - a.updatedAt);
      resolve(items);
    };
    req.onerror = () => reject(req.error);
  });
}

export async function saveNote(note: VaultNote): Promise<void> {
  const db = await getDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('notes', 'readwrite');
    const store = tx.objectStore('notes');
    const req = store.put(note);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export async function deleteNote(id: string): Promise<void> {
  const db = await getDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('notes', 'readwrite');
    const store = tx.objectStore('notes');
    const req = store.delete(id);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

// Clear all data
export async function clearAllVaultData(): Promise<void> {
  const db = await getDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(['files', 'notes'], 'readwrite');
    tx.objectStore('files').clear();
    tx.objectStore('notes').clear();
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

// Factory reset (clear config, files, notes)
export async function factoryResetVault(): Promise<void> {
  const db = await getDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(['config', 'files', 'notes'], 'readwrite');
    tx.objectStore('config').clear();
    tx.objectStore('files').clear();
    tx.objectStore('notes').clear();
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

// Storage estimate helper
export async function getStorageEstimate(): Promise<StorageEstimate> {
  if (navigator.storage && navigator.storage.estimate) {
    try {
      const estimate = await navigator.storage.estimate();
      const usage = estimate.usage || 0;
      const quota = estimate.quota || 1;
      const percentUsed = Math.min(100, Math.round((usage / quota) * 100));

      const formatBytes = (bytes: number) => {
        if (bytes < 1024) return bytes + ' B';
        if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
        if (bytes < 1024 * 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
        return (bytes / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
      };

      return {
        usage,
        quota,
        percentUsed,
        usageFormatted: formatBytes(usage),
        quotaFormatted: formatBytes(quota),
      };
    } catch {
      // ignore
    }
  }

  return {
    usage: 0,
    quota: 0,
    percentUsed: 0,
    usageFormatted: 'Unknown',
    quotaFormatted: 'Unknown',
  };
}
