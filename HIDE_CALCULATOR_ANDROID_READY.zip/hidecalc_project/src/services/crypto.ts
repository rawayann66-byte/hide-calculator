/**
 * Client-Side Cryptographic Service using Web Crypto API.
 * Uses PBKDF2 (SHA-256, 100,000 iterations) for key derivation & PIN hashing,
 * and AES-GCM 256-bit with unique random 12-byte IV for file encryption.
 * No plaintext PINs or encryption keys are ever transmitted or written to storage.
 */

const PBKDF2_ITERATIONS = 100_000;
const AES_KEY_LENGTH = 256;
const IV_LENGTH_BYTES = 12;

// Utility: ArrayBuffer <-> Base64 (Chunked to prevent stack/string overflow with large files)
export function bufferToBase64(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  const chunkSize = 0x8000; // 32KB chunks
  let binary = '';
  for (let i = 0; i < bytes.length; i += chunkSize) {
    const chunk = bytes.subarray(i, Math.min(i + chunkSize, bytes.length));
    binary += String.fromCharCode.apply(null, chunk as unknown as number[]);
  }
  return window.btoa(binary);
}

export function base64ToBuffer(base64: string): ArrayBuffer {
  const binary = window.atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes.buffer;
}

// Generate random salt
export function generateRandomSalt(length = 16): string {
  const salt = new Uint8Array(length);
  window.crypto.getRandomValues(salt);
  return bufferToBase64(salt.buffer);
}

// Derive a raw verification hash of the PIN using PBKDF2
export async function hashPin(pin: string, saltBase64: string): Promise<string> {
  const enc = new TextEncoder();
  const pinKey = await window.crypto.subtle.importKey(
    'raw',
    enc.encode(pin),
    { name: 'PBKDF2' },
    false,
    ['deriveBits']
  );

  const salt = base64ToBuffer(saltBase64);
  const derivedBits = await window.crypto.subtle.deriveBits(
    {
      name: 'PBKDF2',
      salt,
      iterations: PBKDF2_ITERATIONS,
      hash: 'SHA-256',
    },
    pinKey,
    256
  );

  return bufferToBase64(derivedBits);
}

// Verify entered PIN against stored PBKDF2 hash
export async function verifyPin(pin: string, saltBase64: string, expectedHash: string): Promise<boolean> {
  try {
    const computedHash = await hashPin(pin, saltBase64);
    return computedHash === expectedHash;
  } catch (err) {
    console.error('PIN verification error:', err);
    return false;
  }
}

// Derive an AES-GCM CryptoKey for encrypting/decrypting vault items
export async function deriveVaultKey(pin: string, vaultSaltBase64: string): Promise<CryptoKey> {
  const enc = new TextEncoder();
  const pinKey = await window.crypto.subtle.importKey(
    'raw',
    enc.encode(pin),
    { name: 'PBKDF2' },
    false,
    ['deriveKey']
  );

  const salt = base64ToBuffer(vaultSaltBase64);

  return window.crypto.subtle.deriveKey(
    {
      name: 'PBKDF2',
      salt,
      iterations: PBKDF2_ITERATIONS,
      hash: 'SHA-256',
    },
    pinKey,
    { name: 'AES-GCM', length: AES_KEY_LENGTH },
    false, // Non-extractable for maximum in-memory security
    ['encrypt', 'decrypt']
  );
}

// Encrypt arbitrary ArrayBuffer or Uint8Array
export async function encryptData(data: ArrayBuffer | Uint8Array, key: CryptoKey): Promise<ArrayBuffer> {
  const iv = new Uint8Array(IV_LENGTH_BYTES);
  window.crypto.getRandomValues(iv);

  const bufferSource = data as BufferSource;

  const ciphertext = await window.crypto.subtle.encrypt(
    {
      name: 'AES-GCM',
      iv,
    },
    key,
    bufferSource
  );

  // Prepend IV to ciphertext: [12 bytes IV][ciphertext]
  const combined = new Uint8Array(iv.length + ciphertext.byteLength);
  combined.set(iv, 0);
  combined.set(new Uint8Array(ciphertext), iv.length);

  return combined.buffer;
}

// Decrypt combined [12-byte IV][ciphertext] back to original ArrayBuffer
export async function decryptData(
  encryptedInput: ArrayBuffer | ArrayBufferView,
  key: CryptoKey
): Promise<ArrayBuffer> {
  if (!encryptedInput) {
    throw new Error('No encrypted data provided.');
  }

  // Safely normalize input to Uint8Array handling byteOffset
  let combinedBytes: Uint8Array;
  if (encryptedInput instanceof Uint8Array) {
    combinedBytes = new Uint8Array(
      encryptedInput.buffer,
      encryptedInput.byteOffset,
      encryptedInput.byteLength
    );
  } else if (ArrayBuffer.isView(encryptedInput)) {
    combinedBytes = new Uint8Array(
      encryptedInput.buffer,
      encryptedInput.byteOffset,
      encryptedInput.byteLength
    );
  } else if (encryptedInput instanceof ArrayBuffer) {
    combinedBytes = new Uint8Array(encryptedInput);
  } else {
    combinedBytes = new Uint8Array(encryptedInput as ArrayBuffer);
  }

  if (combinedBytes.byteLength <= IV_LENGTH_BYTES) {
    throw new Error('Corrupted encrypted data: payload too short.');
  }

  const iv = combinedBytes.slice(0, IV_LENGTH_BYTES);
  const ciphertext = combinedBytes.slice(IV_LENGTH_BYTES);

  return window.crypto.subtle.decrypt(
    {
      name: 'AES-GCM',
      iv,
    },
    key,
    ciphertext
  );
}

// Encrypt UTF-8 text (e.g. secret notes)
export async function encryptText(text: string, key: CryptoKey): Promise<ArrayBuffer> {
  const enc = new TextEncoder();
  return encryptData(enc.encode(text), key);
}

// Decrypt UTF-8 text
export async function decryptText(encryptedBuffer: ArrayBuffer | ArrayBufferView, key: CryptoKey): Promise<string> {
  const decryptedBuf = await decryptData(encryptedBuffer, key);
  const dec = new TextDecoder();
  return dec.decode(decryptedBuf);
}

// Multi-candidate recovery helper for migrating or rescuing items
export async function tryDecryptWithCandidates(
  encryptedData: ArrayBuffer | ArrayBufferView,
  candidatePins: string[],
  candidateSalts: string[]
): Promise<{ decrypted: ArrayBuffer; pin: string; salt: string } | null> {
  for (const salt of candidateSalts) {
    if (!salt) continue;
    for (const pin of candidatePins) {
      if (!pin) continue;
      try {
        const testKey = await deriveVaultKey(pin, salt);
        const decrypted = await decryptData(encryptedData, testKey);
        if (decrypted && decrypted.byteLength > 0) {
          return { decrypted, pin, salt };
        }
      } catch {
        // Continue testing other combinations
      }
    }
  }
  return null;
}
