import React, { useState } from 'react';
import { Lock, Shield, Eye, EyeOff, Check, X, KeyRound } from 'lucide-react';

interface SetupPinGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSavePin: (pin: string) => Promise<void>;
  prefilledPin?: string;
}

export const SetupPinGuideModal: React.FC<SetupPinGuideModalProps> = ({
  isOpen,
  onClose,
  onSavePin,
  prefilledPin = '',
}) => {
  const [pin, setPin] = useState(prefilledPin);
  const [confirmPin, setConfirmPin] = useState('');
  const [showPin, setShowPin] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (pin.length !== 4 || !/^\d{4}$/.test(pin)) {
      setError('PIN must be exactly 4 numeric digits (0-9).');
      return;
    }

    if (pin !== confirmPin) {
      setError('PINs do not match. Please re-enter carefully.');
      return;
    }

    setIsSubmitting(true);
    try {
      await onSavePin(pin);
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to set PIN');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-zinc-950 border border-zinc-800 rounded-2xl p-6 shadow-2xl text-white">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-900 transition-colors"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 rounded-xl bg-zinc-900 border border-zinc-700 flex items-center justify-center text-white">
            <Lock className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-lg font-bold tracking-tight text-white">Secret Vault Setup</h2>
            <p className="text-xs text-zinc-400">Configure your disguise calculator unlock code</p>
          </div>
        </div>

        {/* Explainer card */}
        <div className="mb-5 p-3.5 rounded-xl bg-zinc-900/80 border border-zinc-800/80 text-xs text-zinc-300 space-y-2">
          <div className="flex items-start gap-2.5">
            <Shield className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <span>
              <strong>How it works:</strong> Type your 4-digit PIN into the calculator and press <kbd className="px-1.5 py-0.5 rounded bg-zinc-800 border border-zinc-700 font-mono text-[11px] text-white">=</kbd> to unlock your private vault anytime.
            </span>
          </div>
          <div className="flex items-start gap-2.5">
            <KeyRound className="w-4 h-4 text-zinc-400 shrink-0 mt-0.5" />
            <span>
              All vault files are encrypted with <strong>AES-256-GCM</strong> on your device using this PIN.
            </span>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-zinc-300 mb-1.5">
              Create 4-Digit Secret PIN
            </label>
            <div className="relative">
              <input
                type={showPin ? 'text' : 'password'}
                inputMode="numeric"
                pattern="[0-9]*"
                maxLength={4}
                value={pin}
                onChange={(e) => {
                  const val = e.target.value.replace(/\D/g, '').slice(0, 4);
                  setPin(val);
                }}
                placeholder="4-digit PIN (e.g. 1984)"
                autoFocus
                className="w-full bg-zinc-900 border border-zinc-700 rounded-xl px-4 py-3 text-white font-mono tracking-widest text-center text-xl placeholder:text-zinc-600 focus:outline-none focus:border-white focus:ring-1 focus:ring-white transition-all"
              />
              <button
                type="button"
                onClick={() => setShowPin(!showPin)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-white p-1"
                aria-label={showPin ? 'Hide PIN' : 'Show PIN'}
              >
                {showPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-zinc-300 mb-1.5">
              Confirm 4-Digit Secret PIN
            </label>
            <input
              type={showPin ? 'text' : 'password'}
              inputMode="numeric"
              pattern="[0-9]*"
              maxLength={4}
              value={confirmPin}
              onChange={(e) => {
                const val = e.target.value.replace(/\D/g, '').slice(0, 4);
                setConfirmPin(val);
              }}
              placeholder="Re-enter PIN"
              className="w-full bg-zinc-900 border border-zinc-700 rounded-xl px-4 py-3 text-white font-mono tracking-widest text-center text-xl placeholder:text-zinc-600 focus:outline-none focus:border-white focus:ring-1 focus:ring-white transition-all"
            />
          </div>

          {error && (
            <div className="p-2.5 rounded-lg bg-red-950/60 border border-red-800 text-red-300 text-xs text-center font-medium">
              {error}
            </div>
          )}

          <div className="flex gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-white text-sm font-medium transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting || pin.length !== 4 || confirmPin.length !== 4}
              className="flex-1 py-3 rounded-xl bg-white hover:bg-zinc-200 text-black text-sm font-semibold flex items-center justify-center gap-2 transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-md"
            >
              {isSubmitting ? (
                'Saving...'
              ) : (
                <>
                  <Check className="w-4 h-4" />
                  Save Secret PIN
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
