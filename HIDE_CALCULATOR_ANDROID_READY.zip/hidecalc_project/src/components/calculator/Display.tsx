import React from 'react';

interface DisplayProps {
  expression: string;
  value: string;
  isError?: boolean;
}

export const Display: React.FC<DisplayProps> = ({ expression, value, isError }) => {
  // Compute dynamic font size based on length of display string
  const getFontSizeClass = (text: string) => {
    const len = text.length;
    if (len <= 6) return 'text-5xl sm:text-6xl';
    if (len <= 9) return 'text-4xl sm:text-5xl';
    if (len <= 12) return 'text-3xl sm:text-4xl';
    return 'text-2xl sm:text-3xl';
  };

  return (
    <div className="w-full flex flex-col justify-end items-end px-5 py-4 min-h-[140px] bg-black text-right select-text">
      {/* Expression line */}
      <div className="h-6 text-sm sm:text-base text-zinc-500 font-mono tracking-wider tabular-nums overflow-hidden text-ellipsis whitespace-nowrap max-w-full">
        {expression || '\u00A0'}
      </div>

      {/* Main output display */}
      <div
        className={`font-mono font-light tracking-tight text-white tabular-nums transition-all duration-100 overflow-x-auto overflow-y-hidden max-w-full ${
          isError ? 'text-red-400 text-2xl sm:text-3xl font-semibold' : getFontSizeClass(value)
        }`}
        style={{ wordBreak: 'break-all' }}
      >
        {value}
      </div>
    </div>
  );
};
