import React, { useState, useEffect, useCallback, useTransition } from 'react';
import { Delete, History, RotateCcw } from 'lucide-react';
import { Display } from './Display';
import { VaultConfig } from '../../types';
import { verifyPin, deriveVaultKey } from '../../services/crypto';
import { playTactileClick, playUnlockChime } from '../../services/audio';

interface CalculatorProps {
  config: VaultConfig;
  onConfigUpdated: (newConfig: VaultConfig) => void;
  onUnlockVault: (pin: string, key: CryptoKey) => void;
  onFakeCrash?: () => void;
}

export const Calculator: React.FC<CalculatorProps> = ({
  config,
  onUnlockVault,
  onFakeCrash,
}) => {
  const [, startTransition] = useTransition();
  const [displayValue, setDisplayValue] = useState<string>('0');
  const [prevValue, setPrevValue] = useState<number | null>(null);
  const [operator, setOperator] = useState<string | null>(null);
  const [waitingForOperand, setWaitingForOperand] = useState<boolean>(false);
  const [expression, setExpression] = useState<string>('');
  const [isError, setIsError] = useState<boolean>(false);

  // History & feedback states
  const [showHistory, setShowHistory] = useState<boolean>(false);
  const [historyList, setHistoryList] = useState<Array<{ expr: string; result: string }>>([]);
  const [unlockFeedback, setUnlockFeedback] = useState<string | null>(null);

  const resetAll = useCallback(() => {
    setDisplayValue('0');
    setPrevValue(null);
    setOperator(null);
    setWaitingForOperand(false);
    setExpression('');
    setIsError(false);
    setUnlockFeedback(null);
  }, []);

  const clearCurrent = useCallback(() => {
    setDisplayValue('0');
    setIsError(false);
    setUnlockFeedback(null);
  }, []);

  // Handle digit inputs
  const inputDigit = useCallback(
    (digit: string) => {
      playTactileClick(config.hapticSound);

      if (unlockFeedback) {
        setUnlockFeedback(null);
      }

      if (isError) {
        setDisplayValue(digit);
        setIsError(false);
        return;
      }

      if (waitingForOperand) {
        setDisplayValue(digit);
        setWaitingForOperand(false);
      } else {
        setDisplayValue((prev) => (prev === '0' ? digit : prev + digit));
      }
    },
    [waitingForOperand, isError, config.hapticSound, unlockFeedback]
  );

  // Handle decimal point
  const inputDecimal = useCallback(() => {
    playTactileClick(config.hapticSound);

    if (unlockFeedback) {
      setUnlockFeedback(null);
    }

    if (isError) {
      setDisplayValue('0.');
      setIsError(false);
      return;
    }

    if (waitingForOperand) {
      setDisplayValue('0.');
      setWaitingForOperand(false);
      return;
    }

    if (!displayValue.includes('.')) {
      setDisplayValue((prev) => prev + '.');
    }
  }, [waitingForOperand, displayValue, isError, config.hapticSound, unlockFeedback]);

  // Handle backspace
  const handleBackspace = useCallback(() => {
    playTactileClick(config.hapticSound);

    if (unlockFeedback) {
      setUnlockFeedback(null);
    }

    if (isError) {
      resetAll();
      return;
    }

    if (waitingForOperand) return;

    if (displayValue.length > 1) {
      setDisplayValue((prev) => prev.slice(0, -1));
    } else {
      setDisplayValue('0');
    }
  }, [displayValue, waitingForOperand, isError, resetAll, config.hapticSound, unlockFeedback]);

  // Handle sign toggle (+/-)
  const toggleSign = useCallback(() => {
    playTactileClick(config.hapticSound);
    if (unlockFeedback) setUnlockFeedback(null);
    if (isError) return;

    const val = parseFloat(displayValue);
    if (isNaN(val)) return;
    const toggled = (-val).toString();
    setDisplayValue(toggled);
  }, [displayValue, isError, config.hapticSound, unlockFeedback]);

  // Handle percentage (%)
  const inputPercentage = useCallback(() => {
    playTactileClick(config.hapticSound);
    if (unlockFeedback) setUnlockFeedback(null);
    if (isError) return;

    const current = parseFloat(displayValue);
    if (isNaN(current)) return;

    let result: number;
    if (prevValue !== null && (operator === '+' || operator === '−')) {
      result = (prevValue * current) / 100;
    } else {
      result = current / 100;
    }

    const cleanResult = parseFloat(result.toPrecision(12)).toString();
    setDisplayValue(cleanResult);
  }, [displayValue, prevValue, operator, isError, config.hapticSound, unlockFeedback]);

  // Calculation helper
  const performCalculation = (op: string, a: number, b: number): number => {
    switch (op) {
      case '+':
        return a + b;
      case '−':
      case '-':
        return a - b;
      case '×':
      case '*':
        return a * b;
      case '÷':
      case '/':
        if (b === 0) throw new Error('Divide by zero');
        return a / b;
      default:
        return b;
    }
  };

  // Perform binary operator (+, -, *, /)
  const performOperation = useCallback(
    (nextOperator: string) => {
      playTactileClick(config.hapticSound);
      if (unlockFeedback) setUnlockFeedback(null);
      if (isError) return;

      const inputValue = parseFloat(displayValue);

      if (prevValue === null) {
        setPrevValue(inputValue);
        setExpression(`${displayValue} ${nextOperator}`);
      } else if (operator && !waitingForOperand) {
        try {
          const currentResult = performCalculation(operator, prevValue, inputValue);
          const cleanResult = parseFloat(currentResult.toPrecision(12));
          setPrevValue(cleanResult);
          setDisplayValue(String(cleanResult));
          setExpression(`${cleanResult} ${nextOperator}`);
        } catch {
          setIsError(true);
          setDisplayValue('Error');
          setPrevValue(null);
          setOperator(null);
          return;
        }
      } else {
        setExpression(`${prevValue} ${nextOperator}`);
      }

      setWaitingForOperand(true);
      setOperator(nextOperator);
    },
    [displayValue, prevValue, operator, waitingForOperand, isError, config.hapticSound, unlockFeedback]
  );

  // Handle Equals (=) - Checks secret PIN when standalone 4 digits are entered!
  const handleEquals = useCallback(async () => {
    playTactileClick(config.hapticSound);

    const cleanDigits = displayValue.trim();

    // Panic action trigger if configured
    if (cleanDigits === '9999' && config.panicAction === 'fake_crash' && onFakeCrash) {
      onFakeCrash();
      return;
    }

    // Secret unlock method:
    // When exactly 4 digits are entered with NO active operator, pressing "=" verifies the PIN
    if (/^\d{4}$/.test(cleanDigits) && operator === null) {
      if (config.isSetup && config.pinHash) {
        try {
          const isValid = await verifyPin(cleanDigits, config.pinSalt, config.pinHash);
          if (isValid) {
            playUnlockChime(config.hapticSound);
            setUnlockFeedback('Vault Unlocked');

            const key = await deriveVaultKey(cleanDigits, config.vaultSalt);
            setTimeout(() => {
              onUnlockVault(cleanDigits, key);
              setUnlockFeedback(null);
            }, 250);
            return;
          } else {
            // Requirement: If incorrect, show a small "Incorrect Code" message
            setUnlockFeedback('Incorrect Code');
            setTimeout(() => {
              setUnlockFeedback((prev) => (prev === 'Incorrect Code' ? null : prev));
            }, 1500);
            return;
          }
        } catch {
          setUnlockFeedback('Incorrect Code');
          setTimeout(() => {
            setUnlockFeedback((prev) => (prev === 'Incorrect Code' ? null : prev));
          }, 1500);
          return;
        }
      }
    }

    // Otherwise execute normal math evaluation
    if (operator === null || prevValue === null) {
      // Nothing to calculate, keep current value
      return;
    }

    const inputValue = parseFloat(displayValue);
    const fullExpr = `${expression} ${displayValue} =`;

    try {
      const result = performCalculation(operator, prevValue, inputValue);
      const cleanResult = parseFloat(result.toPrecision(12)).toString();

      setExpression(fullExpr);
      setDisplayValue(cleanResult);
      setPrevValue(null);
      setOperator(null);
      setWaitingForOperand(true);

      // Save to calculation history
      setHistoryList((prev) => [{ expr: fullExpr, result: cleanResult }, ...prev.slice(0, 19)]);
    } catch {
      setIsError(true);
      setDisplayValue('Error');
      setPrevValue(null);
      setOperator(null);
      setExpression(fullExpr);
    }
  }, [
    displayValue,
    expression,
    operator,
    prevValue,
    config,
    onUnlockVault,
    onFakeCrash,
  ]);

  // Keyboard shortcut listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return;
      }

      if (e.key >= '0' && e.key <= '9') {
        e.preventDefault();
        inputDigit(e.key);
      } else if (e.key === '.') {
        e.preventDefault();
        inputDecimal();
      } else if (e.key === '+' || e.key === '-') {
        e.preventDefault();
        performOperation(e.key === '-' ? '−' : '+');
      } else if (e.key === '*' || e.key === 'x' || e.key === 'X') {
        e.preventDefault();
        performOperation('×');
      } else if (e.key === '/') {
        e.preventDefault();
        performOperation('÷');
      } else if (e.key === '=' || e.key === 'Enter') {
        e.preventDefault();
        startTransition(() => {
          handleEquals();
        });
      } else if (e.key === 'Backspace') {
        e.preventDefault();
        handleBackspace();
      } else if (e.key === 'Escape' || e.key === 'c' || e.key === 'C') {
        e.preventDefault();
        resetAll();
      } else if (e.key === '%') {
        e.preventDefault();
        inputPercentage();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [
    inputDigit,
    inputDecimal,
    performOperation,
    handleEquals,
    handleBackspace,
    resetAll,
    inputPercentage,
  ]);

  return (
    <div className="relative w-full max-w-sm sm:max-w-md mx-auto flex flex-col items-center select-none">
      {/* Sleek Device / Disguise Housing */}
      <div className="w-full bg-zinc-950 border border-zinc-800 rounded-3xl p-4 sm:p-5 shadow-2xl overflow-hidden relative backdrop-blur-xl">
        {/* Disguise Top App Bar: Brand + History Only (No Secret PIN button) */}
        <div className="flex items-center justify-between px-2 pb-3 mb-1 border-b border-zinc-900 text-xs text-zinc-500">
          <div className="flex items-center gap-2">
            <span className="font-semibold tracking-widest text-zinc-400 font-mono text-[11px]">
              HIDE
            </span>
            <span className="text-[10px] text-zinc-600 font-mono">CALC-100</span>
          </div>

          <div className="flex items-center gap-1.5">
            {/* Calculation History Button */}
            <button
              onClick={() => setShowHistory(!showHistory)}
              className={`p-1.5 rounded-lg transition-colors ${
                showHistory ? 'bg-zinc-800 text-white' : 'text-zinc-500 hover:text-zinc-300 hover:bg-zinc-900'
              }`}
              title="Calculation History"
              aria-label="History"
            >
              <History className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Calculation History Dropdown / Overlay */}
        {showHistory && (
          <div className="mb-3 p-3 bg-zinc-900/90 border border-zinc-800 rounded-xl max-h-40 overflow-y-auto text-xs space-y-1.5">
            <div className="flex items-center justify-between text-zinc-400 font-medium mb-1">
              <span>Recent Calculations</span>
              {historyList.length > 0 && (
                <button
                  onClick={() => setHistoryList([])}
                  className="text-[11px] text-zinc-500 hover:text-zinc-300 flex items-center gap-1"
                >
                  <RotateCcw className="w-3 h-3" /> Clear
                </button>
              )}
            </div>
            {historyList.length === 0 ? (
              <p className="text-zinc-600 text-center py-2">No previous calculations</p>
            ) : (
              historyList.map((item, idx) => (
                <div
                  key={idx}
                  onClick={() => {
                    setDisplayValue(item.result);
                    setWaitingForOperand(true);
                  }}
                  className="flex items-center justify-between py-1 px-1.5 rounded hover:bg-zinc-800/80 cursor-pointer font-mono"
                >
                  <span className="text-zinc-400 truncate max-w-[180px]">{item.expr}</span>
                  <span className="text-white font-semibold">{item.result}</span>
                </div>
              ))
            )}
          </div>
        )}

        {/* Screen Display */}
        <Display expression={expression} value={displayValue} isError={isError} />

        {/* Small "Incorrect Code" or "Vault Unlocked" Feedback Message */}
        <div className="min-h-[24px] flex items-center justify-center my-1.5">
          {unlockFeedback && (
            <span
              className={`text-[11px] px-3 py-0.5 rounded-full font-medium transition-all animate-in fade-in zoom-in-95 duration-150 ${
                unlockFeedback === 'Incorrect Code'
                  ? 'bg-red-950/80 border border-red-800/80 text-red-300 shadow-sm'
                  : 'bg-emerald-950/80 border border-emerald-800/80 text-emerald-300 shadow-sm'
              }`}
            >
              {unlockFeedback}
            </span>
          )}
        </div>

        {/* Calculator Keypad Grid: 4 columns */}
        <div className="grid grid-cols-4 gap-2.5 sm:gap-3">
          {/* Row 1: AC, Backspace, %, ÷ */}
          <button
            onClick={displayValue !== '0' ? clearCurrent : resetAll}
            className="h-14 sm:h-16 rounded-2xl bg-zinc-800 hover:bg-zinc-700 active:scale-95 text-white text-lg font-medium transition-all shadow-sm flex items-center justify-center"
          >
            {displayValue !== '0' ? 'C' : 'AC'}
          </button>

          <button
            onClick={handleBackspace}
            className="h-14 sm:h-16 rounded-2xl bg-zinc-800 hover:bg-zinc-700 active:scale-95 text-white transition-all shadow-sm flex items-center justify-center"
            title="Backspace"
            aria-label="Backspace"
          >
            <Delete className="w-5 h-5 text-zinc-300" />
          </button>

          <button
            onClick={inputPercentage}
            className="h-14 sm:h-16 rounded-2xl bg-zinc-800 hover:bg-zinc-700 active:scale-95 text-white text-lg font-medium transition-all shadow-sm flex items-center justify-center font-mono"
          >
            %
          </button>

          <button
            onClick={() => performOperation('÷')}
            className={`h-14 sm:h-16 rounded-2xl active:scale-95 text-xl font-medium transition-all shadow-sm flex items-center justify-center font-mono ${
              operator === '÷'
                ? 'bg-white text-black ring-2 ring-white'
                : 'bg-zinc-700 hover:bg-zinc-600 text-white'
            }`}
          >
            ÷
          </button>

          {/* Row 2: 7, 8, 9, × */}
          <button
            onClick={() => inputDigit('7')}
            className="h-14 sm:h-16 rounded-2xl bg-zinc-900/90 hover:bg-zinc-800 active:scale-95 text-white text-xl sm:text-2xl font-mono font-medium transition-all border border-zinc-800/60 shadow-sm flex items-center justify-center"
          >
            7
          </button>
          <button
            onClick={() => inputDigit('8')}
            className="h-14 sm:h-16 rounded-2xl bg-zinc-900/90 hover:bg-zinc-800 active:scale-95 text-white text-xl sm:text-2xl font-mono font-medium transition-all border border-zinc-800/60 shadow-sm flex items-center justify-center"
          >
            8
          </button>
          <button
            onClick={() => inputDigit('9')}
            className="h-14 sm:h-16 rounded-2xl bg-zinc-900/90 hover:bg-zinc-800 active:scale-95 text-white text-xl sm:text-2xl font-mono font-medium transition-all border border-zinc-800/60 shadow-sm flex items-center justify-center"
          >
            9
          </button>
          <button
            onClick={() => performOperation('×')}
            className={`h-14 sm:h-16 rounded-2xl active:scale-95 text-xl font-medium transition-all shadow-sm flex items-center justify-center font-mono ${
              operator === '×'
                ? 'bg-white text-black ring-2 ring-white'
                : 'bg-zinc-700 hover:bg-zinc-600 text-white'
            }`}
          >
            ×
          </button>

          {/* Row 3: 4, 5, 6, − */}
          <button
            onClick={() => inputDigit('4')}
            className="h-14 sm:h-16 rounded-2xl bg-zinc-900/90 hover:bg-zinc-800 active:scale-95 text-white text-xl sm:text-2xl font-mono font-medium transition-all border border-zinc-800/60 shadow-sm flex items-center justify-center"
          >
            4
          </button>
          <button
            onClick={() => inputDigit('5')}
            className="h-14 sm:h-16 rounded-2xl bg-zinc-900/90 hover:bg-zinc-800 active:scale-95 text-white text-xl sm:text-2xl font-mono font-medium transition-all border border-zinc-800/60 shadow-sm flex items-center justify-center"
          >
            5
          </button>
          <button
            onClick={() => inputDigit('6')}
            className="h-14 sm:h-16 rounded-2xl bg-zinc-900/90 hover:bg-zinc-800 active:scale-95 text-white text-xl sm:text-2xl font-mono font-medium transition-all border border-zinc-800/60 shadow-sm flex items-center justify-center"
          >
            6
          </button>
          <button
            onClick={() => performOperation('−')}
            className={`h-14 sm:h-16 rounded-2xl active:scale-95 text-xl font-medium transition-all shadow-sm flex items-center justify-center font-mono ${
              operator === '−'
                ? 'bg-white text-black ring-2 ring-white'
                : 'bg-zinc-700 hover:bg-zinc-600 text-white'
            }`}
          >
            −
          </button>

          {/* Row 4: 1, 2, 3, + */}
          <button
            onClick={() => inputDigit('1')}
            className="h-14 sm:h-16 rounded-2xl bg-zinc-900/90 hover:bg-zinc-800 active:scale-95 text-white text-xl sm:text-2xl font-mono font-medium transition-all border border-zinc-800/60 shadow-sm flex items-center justify-center"
          >
            1
          </button>
          <button
            onClick={() => inputDigit('2')}
            className="h-14 sm:h-16 rounded-2xl bg-zinc-900/90 hover:bg-zinc-800 active:scale-95 text-white text-xl sm:text-2xl font-mono font-medium transition-all border border-zinc-800/60 shadow-sm flex items-center justify-center"
          >
            2
          </button>
          <button
            onClick={() => inputDigit('3')}
            className="h-14 sm:h-16 rounded-2xl bg-zinc-900/90 hover:bg-zinc-800 active:scale-95 text-white text-xl sm:text-2xl font-mono font-medium transition-all border border-zinc-800/60 shadow-sm flex items-center justify-center"
          >
            3
          </button>
          <button
            onClick={() => performOperation('+')}
            className={`h-14 sm:h-16 rounded-2xl active:scale-95 text-xl font-medium transition-all shadow-sm flex items-center justify-center font-mono ${
              operator === '+'
                ? 'bg-white text-black ring-2 ring-white'
                : 'bg-zinc-700 hover:bg-zinc-600 text-white'
            }`}
          >
            +
          </button>

          {/* Row 5: +/-, 0, ., = */}
          <button
            onClick={toggleSign}
            className="h-14 sm:h-16 rounded-2xl bg-zinc-800 hover:bg-zinc-700 active:scale-95 text-white text-base font-medium transition-all shadow-sm flex items-center justify-center font-mono"
            title="Toggle Sign"
          >
            ±
          </button>
          <button
            onClick={() => inputDigit('0')}
            className="h-14 sm:h-16 rounded-2xl bg-zinc-900/90 hover:bg-zinc-800 active:scale-95 text-white text-xl sm:text-2xl font-mono font-medium transition-all border border-zinc-800/60 shadow-sm flex items-center justify-center"
          >
            0
          </button>
          <button
            onClick={inputDecimal}
            className="h-14 sm:h-16 rounded-2xl bg-zinc-900/90 hover:bg-zinc-800 active:scale-95 text-white text-2xl font-mono font-bold transition-all border border-zinc-800/60 shadow-sm flex items-center justify-center"
          >
            .
          </button>
          <button
            onClick={() => {
              startTransition(() => {
                handleEquals();
              });
            }}
            className="h-14 sm:h-16 rounded-2xl bg-white hover:bg-zinc-200 active:scale-95 text-black text-2xl font-mono font-bold transition-all shadow-lg shadow-white/10 flex items-center justify-center"
            title="Calculate or Unlock Secret Vault"
            aria-label="Equals"
          >
            =
          </button>
        </div>
      </div>
    </div>
  );
};
