import React, { useState, useEffect, useCallback } from 'react';
import { X, ZoomIn, ZoomOut, RotateCw, Download, Trash2, ChevronLeft, ChevronRight, FileText } from 'lucide-react';
import { DecryptedFileItem } from '../../types';

interface MediaViewerModalProps {
  item: DecryptedFileItem | null;
  allItems?: DecryptedFileItem[];
  onClose: () => void;
  onDelete: (id: string) => Promise<void>;
  onNavigate?: (item: DecryptedFileItem) => void;
}

export const MediaViewerModal: React.FC<MediaViewerModalProps> = ({
  item,
  allItems = [],
  onClose,
  onDelete,
  onNavigate,
}) => {
  const [zoom, setZoom] = useState<number>(1);
  const [rotation, setRotation] = useState<number>(0);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  // Reset transforms when item changes
  useEffect(() => {
    setZoom(1);
    setRotation(0);
    setIsDeleting(false);
  }, [item?.id]);

  const currentIndex = item && allItems.length > 0 ? allItems.findIndex((f) => f.id === item.id) : -1;
  const hasPrev = currentIndex > 0;
  const hasNext = currentIndex !== -1 && currentIndex < allItems.length - 1;

  const handlePrev = useCallback(() => {
    if (hasPrev && onNavigate) {
      onNavigate(allItems[currentIndex - 1]);
    }
  }, [hasPrev, onNavigate, allItems, currentIndex]);

  const handleNext = useCallback(() => {
    if (hasNext && onNavigate) {
      onNavigate(allItems[currentIndex + 1]);
    }
  }, [hasNext, onNavigate, allItems, currentIndex]);

  // Keyboard navigation
  useEffect(() => {
    if (!item) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      else if (e.key === 'ArrowLeft') handlePrev();
      else if (e.key === 'ArrowRight') handleNext();
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [item, onClose, handlePrev, handleNext]);

  if (!item) return null;

  const handleDownload = () => {
    const a = document.createElement('a');
    a.href = item.blobUrl;
    a.download = item.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleDeleteConfirm = async () => {
    if (window.confirm(`Delete "${item.name}" from your private vault? This cannot be undone.`)) {
      setIsDeleting(true);
      await onDelete(item.id);
      setIsDeleting(false);
      onClose();
    }
  };

  const formatSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-black/95 backdrop-blur-xl select-none animate-in fade-in duration-200">
      {/* Top Header Controls */}
      <div className="flex items-center justify-between px-4 py-3 bg-zinc-950/90 border-b border-zinc-800 text-white z-10">
        <div className="flex items-center gap-3 overflow-hidden pr-4">
          <span className="text-sm font-semibold truncate text-zinc-200">{item.name}</span>
          <span className="text-xs text-zinc-500 shrink-0 font-mono">
            {formatSize(item.size)}
          </span>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          {item.type === 'photo' && (
            <>
              <button
                onClick={() => setZoom((prev) => Math.max(0.5, prev - 0.25))}
                className="p-2 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-900 transition-colors"
                title="Zoom Out"
                aria-label="Zoom Out"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <button
                onClick={() => setZoom((prev) => Math.min(3, prev + 0.25))}
                className="p-2 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-900 transition-colors"
                title="Zoom In"
                aria-label="Zoom In"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
              <button
                onClick={() => setRotation((prev) => (prev + 90) % 360)}
                className="p-2 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-900 transition-colors"
                title="Rotate 90°"
                aria-label="Rotate"
              >
                <RotateCw className="w-4 h-4" />
              </button>
            </>
          )}

          <button
            onClick={handleDownload}
            className="p-2 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-900 transition-colors"
            title="Download Decrypted File"
            aria-label="Download"
          >
            <Download className="w-4 h-4" />
          </button>

          <button
            onClick={handleDeleteConfirm}
            disabled={isDeleting}
            className="p-2 text-red-400 hover:text-red-300 rounded-lg hover:bg-zinc-900 transition-colors disabled:opacity-50"
            title="Delete File"
            aria-label="Delete"
          >
            <Trash2 className="w-4 h-4" />
          </button>

          <button
            onClick={onClose}
            className="p-2 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-900 transition-colors ml-2"
            title="Close Preview"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Main Preview Canvas */}
      <div className="relative flex-1 flex items-center justify-center p-4 overflow-hidden">
        {/* Navigation Previous */}
        {hasPrev && (
          <button
            onClick={handlePrev}
            className="absolute left-4 top-1/2 -translate-y-1/2 z-20 p-3 rounded-full bg-zinc-900/80 hover:bg-zinc-800 text-white border border-zinc-700 shadow-xl transition-all"
            aria-label="Previous file"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
        )}

        {/* Navigation Next */}
        {hasNext && (
          <button
            onClick={handleNext}
            className="absolute right-4 top-1/2 -translate-y-1/2 z-20 p-3 rounded-full bg-zinc-900/80 hover:bg-zinc-800 text-white border border-zinc-700 shadow-xl transition-all"
            aria-label="Next file"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        )}

        {/* Content Render */}
        {item.type === 'photo' && (
          <div className="w-full h-full flex items-center justify-center overflow-auto">
            <img
              src={item.blobUrl}
              alt={item.name}
              className="max-h-[85vh] max-w-[90vw] object-contain transition-transform duration-200 select-none shadow-2xl rounded-lg"
              style={{
                transform: `scale(${zoom}) rotate(${rotation}deg)`,
              }}
              draggable={false}
            />
          </div>
        )}

        {item.type === 'video' && (
          <div className="w-full max-w-4xl max-h-[80vh] flex items-center justify-center">
            <video
              src={item.blobUrl}
              controls
              autoPlay
              playsInline
              className="w-full max-h-[80vh] rounded-xl shadow-2xl bg-black"
            />
          </div>
        )}

        {item.type === 'file' && (
          <div className="w-full max-w-4xl h-[80vh] flex flex-col items-center justify-center bg-zinc-900/80 border border-zinc-800 rounded-2xl p-6">
            {item.mimeType === 'application/pdf' ? (
              <iframe
                src={item.blobUrl}
                title={item.name}
                className="w-full h-full rounded-xl border border-zinc-800 bg-white"
              />
            ) : item.mimeType.startsWith('text/') ? (
              <iframe
                src={item.blobUrl}
                title={item.name}
                className="w-full h-full rounded-xl border border-zinc-800 bg-zinc-950 p-4 font-mono text-xs text-zinc-300 overflow-auto"
              />
            ) : (
              <div className="text-center space-y-4">
                <div className="w-20 h-20 rounded-2xl bg-zinc-800 border border-zinc-700 flex items-center justify-center mx-auto text-zinc-300">
                  <FileText className="w-10 h-10" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white mb-1">{item.name}</h3>
                  <p className="text-xs text-zinc-400 font-mono">
                    {item.mimeType || 'Binary Document'} · {formatSize(item.size)}
                  </p>
                </div>
                <button
                  onClick={handleDownload}
                  className="px-6 py-2.5 rounded-xl bg-white hover:bg-zinc-200 text-black text-sm font-semibold flex items-center gap-2 mx-auto transition-colors shadow-lg"
                >
                  <Download className="w-4 h-4" />
                  Download & Open Document
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Footer Info */}
      <div className="px-6 py-2.5 bg-zinc-950 border-t border-zinc-900 text-center text-xs text-zinc-500 font-mono">
        Added {new Date(item.createdAt).toLocaleDateString()} {new Date(item.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} · Client Encrypted (AES-256-GCM)
      </div>
    </div>
  );
};
