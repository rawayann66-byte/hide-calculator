import React, { useState, useEffect, useRef } from 'react';
import {
  Shield,
  KeyRound,
  Download,
  Upload,
  Trash2,
  HardDrive,
  AlertTriangle,
  Check,
  Volume2,
  VolumeX,
  FileArchive,
  RefreshCw,
  Lock,
} from 'lucide-react';
import JSZip from 'jszip';
import { VaultConfig, DecryptedFileItem, DecryptedNote, StorageEstimate } from '../../types';
import {
  saveConfig,
  getStorageEstimate,
  getAllFiles,
  getAllNotes,
  clearAllVaultData,
  factoryResetVault,
  saveFile,
  saveNote,
} from '../../services/db';
import {
  verifyPin,
  hashPin,
  generateRandomSalt,
  deriveVaultKey,
  encryptData,
  decryptData,
  encryptText,
  decryptText,
  bufferToBase64,
  base64ToBuffer,
} from '../../services/crypto';

interface SettingsTabProps {
  config: VaultConfig;
  currentPin: string;
  vaultKey: CryptoKey;
  photos: DecryptedFileItem[];
  videos: DecryptedFileItem[];
  files: DecryptedFileItem[];
  notes: DecryptedNote[];
  onConfigUpdated: (newConfig: VaultConfig) => void;
  onPinChanged: (newPin: string, newKey: CryptoKey) => void;
  onRefreshAll: () => Promise<void>;
  onLockVault: () => void;
}

export const SettingsTab: React.FC<SettingsTabProps> = ({
  config,
  currentPin,
  vaultKey,
  photos,
  videos,
  files,
  notes,
  onConfigUpdated,
  onPinChanged,
  onRefreshAll,
  onLockVault,
}) => {
  // Change PIN states
  const [oldPin, setOldPin] = useState('');
  const [newPin, setNewPin] = useState('');
  const [confirmNewPin, setConfirmNewPin] = useState('');
  const [pinChangeError, setPinChangeError] = useState<string | null>(null);
  const [pinChangeSuccess, setPinChangeSuccess] = useState<boolean>(false);
  const [isChangingPin, setIsChangingPin] = useState<boolean>(false);

  // Storage estimate
  const [storage, setStorage] = useState<StorageEstimate | null>(null);

  // Export / Backup states
  const [isExportingZip, setIsExportingZip] = useState(false);
  const [isExportingBackup, setIsExportingBackup] = useState(false);
  const [isImportingBackup, setIsImportingBackup] = useState(false);
  const backupInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    getStorageEstimate().then(setStorage);
  }, [photos.length, videos.length, files.length, notes.length]);

  // Handle PIN Change
  const handleChangePin = async (e: React.FormEvent) => {
    e.preventDefault();
    setPinChangeError(null);
    setPinChangeSuccess(false);

    if (oldPin !== currentPin) {
      setPinChangeError('Current PIN is incorrect.');
      return;
    }

    if (newPin.length !== 4 || !/^\d{4}$/.test(newPin)) {
      setPinChangeError('New PIN must be exactly 4 digits.');
      return;
    }

    if (newPin !== confirmNewPin) {
      setPinChangeError('New PINs do not match.');
      return;
    }

    setIsChangingPin(true);
    try {
      const pinSalt = generateRandomSalt(16);
      const vaultSalt = generateRandomSalt(16);
      const pinHash = await hashPin(newPin, pinSalt);
      const newDerivedKey = await deriveVaultKey(newPin, vaultSalt);

      // Re-encrypt all existing stored files from old key to new key
      const rawFiles = await getAllFiles();
      for (const file of rawFiles) {
        try {
          const decrypted = await decryptData(file.encryptedData, vaultKey);
          const reEncrypted = await encryptData(decrypted, newDerivedKey);
          await saveFile({ ...file, encryptedData: reEncrypted });
        } catch {
          // If a file was from an older key, try candidates or keep as is
        }
      }

      // Re-encrypt all notes from old key to new key
      const rawNotes = await getAllNotes();
      for (const note of rawNotes) {
        try {
          const text = await decryptText(note.encryptedContent, vaultKey);
          const reEncrypted = await encryptText(text, newDerivedKey);
          await saveNote({ ...note, encryptedContent: reEncrypted });
        } catch {
          // ignore
        }
      }

      const historicalSalts = [
        config.vaultSalt,
        ...(config.historicalSalts || []),
      ].filter(Boolean);

      const updated = await saveConfig({
        pinSalt,
        pinHash,
        vaultSalt,
        historicalSalts,
      });

      onConfigUpdated(updated);
      onPinChanged(newPin, newDerivedKey);
      await onRefreshAll();

      setPinChangeSuccess(true);
      setOldPin('');
      setNewPin('');
      setConfirmNewPin('');
      setTimeout(() => setPinChangeSuccess(false), 4000);
    } catch (err) {
      console.error('Failed to change PIN:', err);
      setPinChangeError('Failed to change PIN. Please try again.');
    } finally {
      setIsChangingPin(false);
    }
  };

  // Toggle config option
  const updateSetting = async (key: keyof VaultConfig, value: unknown) => {
    const updated = await saveConfig({ [key]: value });
    onConfigUpdated(updated);
  };

  // Export Decrypted ZIP (convenient offline copy for user)
  const handleExportZip = async () => {
    setIsExportingZip(true);
    try {
      const zip = new JSZip();

      // Photos folder
      if (photos.length > 0) {
        const photoFolder = zip.folder('Photos');
        for (const photo of photos) {
          const resp = await fetch(photo.blobUrl);
          const blob = await resp.blob();
          photoFolder?.file(photo.name, blob);
        }
      }

      // Videos folder
      if (videos.length > 0) {
        const videoFolder = zip.folder('Videos');
        for (const video of videos) {
          const resp = await fetch(video.blobUrl);
          const blob = await resp.blob();
          videoFolder?.file(video.name, blob);
        }
      }

      // Files folder
      if (files.length > 0) {
        const fileFolder = zip.folder('Documents');
        for (const file of files) {
          const resp = await fetch(file.blobUrl);
          const blob = await resp.blob();
          fileFolder?.file(file.name, blob);
        }
      }

      // Notes folder
      if (notes.length > 0) {
        const notesFolder = zip.folder('Notes');
        for (const note of notes) {
          notesFolder?.file(`${note.title.replace(/[\\/:*?"<>|]/g, '_')}.txt`, note.content);
        }
      }

      const content = await zip.generateAsync({ type: 'blob' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(content);
      a.download = `HideCalculator_Decrypted_Backup_${new Date().toISOString().slice(0, 10)}.zip`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } catch (err) {
      console.error('ZIP export error:', err);
      alert('Failed to generate ZIP archive.');
    } finally {
      setIsExportingZip(false);
    }
  };

  // Export Raw Encrypted Backup (.vaultbackup JSON file)
  const handleExportEncryptedBackup = async () => {
    setIsExportingBackup(true);
    try {
      const rawFiles = await getAllFiles();
      const rawNotes = await getAllNotes();

      const backupPayload = {
        format: 'hide_calculator_encrypted_backup_v1',
        exportedAt: Date.now(),
        config: {
          pinSalt: config.pinSalt,
          pinHash: config.pinHash,
          vaultSalt: config.vaultSalt,
          autoLockDelay: config.autoLockDelay,
          lockOnBlur: config.lockOnBlur,
        },
        files: rawFiles.map((f) => ({
          ...f,
          encryptedDataBase64: bufferToBase64(f.encryptedData),
          encryptedData: undefined,
        })),
        notes: rawNotes.map((n) => ({
          ...n,
          encryptedContentBase64: bufferToBase64(n.encryptedContent),
          encryptedContent: undefined,
        })),
      };

      const jsonStr = JSON.stringify(backupPayload, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `HideCalculator_Encrypted_${new Date().toISOString().slice(0, 10)}.vaultbackup`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } catch (err) {
      console.error('Encrypted backup export error:', err);
      alert('Failed to export encrypted backup.');
    } finally {
      setIsExportingBackup(false);
    }
  };

  // Import Encrypted Backup
  const handleImportBackup = async (file: File) => {
    setIsImportingBackup(true);
    try {
      const text = await file.text();
      const parsed = JSON.parse(text);

      if (parsed.format !== 'hide_calculator_encrypted_backup_v1') {
        throw new Error('Unsupported backup format.');
      }

      if (
        !window.confirm(
          `Import backup with ${parsed.files?.length || 0} files and ${parsed.notes?.length || 0} notes? Existing items will be preserved and merged.`
        )
      ) {
        return;
      }

      // Import files
      if (Array.isArray(parsed.files)) {
        for (const f of parsed.files) {
          if (f.encryptedDataBase64) {
            const encryptedData = base64ToBuffer(f.encryptedDataBase64);
            await saveFile({
              id: f.id,
              name: f.name,
              type: f.type,
              mimeType: f.mimeType,
              size: f.size,
              createdAt: f.createdAt,
              encryptedData,
            });
          }
        }
      }

      // Import notes
      if (Array.isArray(parsed.notes)) {
        for (const n of parsed.notes) {
          if (n.encryptedContentBase64) {
            const encryptedContent = base64ToBuffer(n.encryptedContentBase64);
            await saveNote({
              id: n.id,
              title: n.title,
              encryptedContent,
              updatedAt: n.updatedAt,
            });
          }
        }
      }

      await onRefreshAll();
      alert('Encrypted backup successfully restored and merged!');
    } catch (err) {
      console.error('Import backup error:', err);
      alert('Failed to import backup file. File might be corrupted or incompatible.');
    } finally {
      setIsImportingBackup(false);
      if (backupInputRef.current) backupInputRef.current.value = '';
    }
  };

  // Clear Vault Data
  const handleClearAllData = async () => {
    const confirmation = window.prompt(
      'Type "CLEAR" to delete all photos, videos, documents, and notes from your vault. Your secret PIN will remain configured.'
    );
    if (confirmation === 'CLEAR') {
      await clearAllVaultData();
      await onRefreshAll();
      alert('All vault files and notes have been cleared.');
    }
  };

  // Factory reset
  const handleFactoryReset = async () => {
    const confirmation = window.prompt(
      'Type "RESET" to wipe everything: all vault files, notes, and PIN configuration. The app will return to initial state.'
    );
    if (confirmation === 'RESET') {
      await factoryResetVault();
      window.location.reload();
    }
  };

  return (
    <div className="space-y-6 max-w-3xl mx-auto text-white select-none pb-8">
      {/* 1. Change Secret PIN */}
      <section className="bg-zinc-950 border border-zinc-800 rounded-2xl p-5 shadow-sm">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-9 h-9 rounded-xl bg-zinc-900 border border-zinc-700 flex items-center justify-center text-white">
            <KeyRound className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white">Change Secret PIN</h3>
            <p className="text-xs text-zinc-400">Update your 4-digit calculator unlock code</p>
          </div>
        </div>

        <form onSubmit={handleChangePin} className="space-y-3.5">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-medium text-zinc-400 mb-1">Current PIN</label>
              <input
                type="password"
                inputMode="numeric"
                maxLength={4}
                value={oldPin}
                onChange={(e) => setOldPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
                placeholder="4 digits"
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-sm text-center font-mono tracking-widest text-white focus:outline-none focus:border-zinc-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-zinc-400 mb-1">New PIN</label>
              <input
                type="password"
                inputMode="numeric"
                maxLength={4}
                value={newPin}
                onChange={(e) => setNewPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
                placeholder="4 digits"
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-sm text-center font-mono tracking-widest text-white focus:outline-none focus:border-zinc-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-zinc-400 mb-1">Confirm New PIN</label>
              <input
                type="password"
                inputMode="numeric"
                maxLength={4}
                value={confirmNewPin}
                onChange={(e) => setConfirmNewPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
                placeholder="4 digits"
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-sm text-center font-mono tracking-widest text-white focus:outline-none focus:border-zinc-500"
              />
            </div>
          </div>

          {pinChangeError && (
            <div className="p-2.5 rounded-lg bg-red-950/70 border border-red-800 text-red-300 text-xs text-center font-medium">
              {pinChangeError}
            </div>
          )}

          {pinChangeSuccess && (
            <div className="p-2.5 rounded-lg bg-emerald-950/70 border border-emerald-800 text-emerald-300 text-xs text-center font-medium flex items-center justify-center gap-1.5">
              <Check className="w-4 h-4" /> PIN successfully updated!
            </div>
          )}

          <div className="flex justify-end pt-1">
            <button
              type="submit"
              disabled={isChangingPin || oldPin.length !== 4 || newPin.length !== 4 || confirmNewPin.length !== 4}
              className="px-4 py-2 rounded-xl bg-white hover:bg-zinc-200 text-black text-xs font-bold transition-all disabled:opacity-40 disabled:cursor-not-allowed shadow-sm"
            >
              {isChangingPin ? 'Updating PIN...' : 'Update Secret PIN'}
            </button>
          </div>
        </form>
      </section>

      {/* 2. Security & Auto-Lock Settings */}
      <section className="bg-zinc-950 border border-zinc-800 rounded-2xl p-5 shadow-sm space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-zinc-900 border border-zinc-700 flex items-center justify-center text-white">
            <Shield className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white">Security & Disguise Behaviors</h3>
            <p className="text-xs text-zinc-400">Configure auto-locking and panic disguise actions</p>
          </div>
        </div>

        <div className="divide-y divide-zinc-900 text-xs">
          {/* Lock on Tab Switch / Blur */}
          <div className="py-3 flex items-center justify-between">
            <div>
              <span className="font-semibold text-white">Instant Lock on Tab Switch</span>
              <p className="text-zinc-500 text-[11px] mt-0.5">
                Automatically locks the vault the moment you switch tabs or minimize the window
              </p>
            </div>
            <button
              onClick={() => updateSetting('lockOnBlur', !config.lockOnBlur)}
              className={`w-11 h-6 rounded-full transition-colors relative flex items-center p-0.5 ${
                config.lockOnBlur ? 'bg-white' : 'bg-zinc-800'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-black transition-transform ${
                  config.lockOnBlur ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Auto-lock timer */}
          <div className="py-3 flex items-center justify-between">
            <div>
              <span className="font-semibold text-white">Auto-Lock Inactivity Timer</span>
              <p className="text-zinc-500 text-[11px] mt-0.5">
                Locks the vault after a period of user inactivity
              </p>
            </div>
            <select
              value={config.autoLockDelay}
              onChange={(e) => updateSetting('autoLockDelay', Number(e.target.value))}
              className="bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3 py-1.5 text-xs focus:outline-none focus:border-zinc-500"
            >
              <option value={60}>1 Minute</option>
              <option value={300}>5 Minutes</option>
              <option value={900}>15 Minutes</option>
              <option value={1800}>30 Minutes</option>
              <option value={0}>Never (Manual only)</option>
            </select>
          </div>

          {/* Haptic & Sound */}
          <div className="py-3 flex items-center justify-between">
            <div>
              <span className="font-semibold text-white">Tactile Feedback & Sounds</span>
              <p className="text-zinc-500 text-[11px] mt-0.5">
                Subtle synthesized mechanical click sound on calculator buttons and unlock chime
              </p>
            </div>
            <button
              onClick={() => updateSetting('hapticSound', !config.hapticSound)}
              className="p-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-white transition-colors"
            >
              {config.hapticSound ? <Volume2 className="w-4 h-4 text-white" /> : <VolumeX className="w-4 h-4 text-zinc-500" />}
            </button>
          </div>

          {/* Panic Action */}
          <div className="py-3 flex items-center justify-between">
            <div>
              <span className="font-semibold text-white">Panic Lock Destination</span>
              <p className="text-zinc-500 text-[11px] mt-0.5">
                What to display when clicking the Quick Panic Lock button
              </p>
            </div>
            <select
              value={config.panicAction}
              onChange={(e) => updateSetting('panicAction', e.target.value)}
              className="bg-zinc-900 border border-zinc-800 text-white rounded-xl px-3 py-1.5 text-xs focus:outline-none focus:border-zinc-500"
            >
              <option value="calculator">Disguise Calculator (Default)</option>
              <option value="fake_crash">Decoy / Fake Crash Screen</option>
            </select>
          </div>
        </div>
      </section>

      {/* 3. Storage & Realistic Browser Limitations Notice */}
      <section className="bg-zinc-950 border border-zinc-800 rounded-2xl p-5 shadow-sm space-y-3.5">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-zinc-900 border border-zinc-700 flex items-center justify-center text-white">
            <HardDrive className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white">Storage & Security Policy</h3>
            <p className="text-xs text-zinc-400">Local device encryption & browser storage guidelines</p>
          </div>
        </div>

        {/* Meter */}
        {storage && (
          <div className="p-3.5 rounded-xl bg-zinc-900/60 border border-zinc-800 space-y-2">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-zinc-400">Browser Quota Usage:</span>
              <span className="text-white font-bold">{storage.usageFormatted} / {storage.quotaFormatted}</span>
            </div>
            <div className="w-full h-1.5 bg-zinc-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-white transition-all"
                style={{ width: `${Math.max(1, storage.percentUsed)}%` }}
              />
            </div>
            <div className="text-[11px] text-zinc-500 flex justify-between">
              <span>{photos.length} photos · {videos.length} videos · {files.length} docs · {notes.length} notes</span>
              <span>{storage.percentUsed}% used</span>
            </div>
          </div>
        )}

        {/* Transparency callout */}
        <div className="p-3.5 rounded-xl bg-zinc-900/40 border border-zinc-800/80 text-xs text-zinc-300 space-y-2">
          <div className="flex items-start gap-2.5">
            <Shield className="w-4 h-4 text-white shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="font-semibold text-white">Zero Third-Party Cloud Transmission</p>
              <p className="text-zinc-400 leading-relaxed text-[11px]">
                Hide Calculator processes everything client-side using the standard <strong>Web Crypto API (AES-GCM 256-bit)</strong> and stores ciphertext in IndexedDB. No files, metadata, or PINs are ever sent to any remote server.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-2.5 pt-1 border-t border-zinc-900">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="font-semibold text-amber-300">Browser Storage Persistence & Limitations</p>
              <p className="text-zinc-400 leading-relaxed text-[11px]">
                Browser IndexedDB storage is tied to this specific web browser and domain. If you clear "Browsing History & Site Data" in browser settings, or if using an ephemeral Private/Incognito browsing window, stored data will be erased.
                <strong> Export regular backups</strong> below to safeguard critical data.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 4. Backup & Export Functionality */}
      <section className="bg-zinc-950 border border-zinc-800 rounded-2xl p-5 shadow-sm space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-zinc-900 border border-zinc-700 flex items-center justify-center text-white">
            <FileArchive className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white">Export & Backup Vault</h3>
            <p className="text-xs text-zinc-400">Download decrypted files or portable encrypted archives</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {/* Export Decrypted ZIP */}
          <button
            onClick={handleExportZip}
            disabled={isExportingZip || (photos.length === 0 && videos.length === 0 && files.length === 0 && notes.length === 0)}
            className="p-3.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 hover:border-zinc-700 text-left transition-all disabled:opacity-40 disabled:cursor-not-allowed group"
          >
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <Download className="w-4 h-4 text-zinc-400 group-hover:text-white" />
                Export Decrypted ZIP
              </span>
            </div>
            <p className="text-[11px] text-zinc-400 leading-relaxed">
              Downloads a readable .zip bundle containing all your private photos, videos, documents, and notes text.
            </p>
            <span className="inline-block mt-2 text-[10px] text-zinc-500 font-mono">
              {isExportingZip ? 'Packaging ZIP...' : 'Generate ZIP'}
            </span>
          </button>

          {/* Export Encrypted Backup (.vaultbackup) */}
          <button
            onClick={handleExportEncryptedBackup}
            disabled={isExportingBackup}
            className="p-3.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 hover:border-zinc-700 text-left transition-all disabled:opacity-40 group"
          >
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <Lock className="w-4 h-4 text-zinc-400 group-hover:text-white" />
                Encrypted Backup (.vaultbackup)
              </span>
            </div>
            <p className="text-[11px] text-zinc-400 leading-relaxed">
              Exports raw AES ciphertext and salts in a secure file you can store on USB or cloud drives safely.
            </p>
            <span className="inline-block mt-2 text-[10px] text-zinc-500 font-mono">
              {isExportingBackup ? 'Exporting...' : 'Export Backup File'}
            </span>
          </button>
        </div>

        {/* Restore Backup */}
        <div className="pt-2 border-t border-zinc-900 flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-white">Restore from Backup</span>
            <p className="text-[11px] text-zinc-500">Restore items from a .vaultbackup file</p>
          </div>
          <button
            onClick={() => backupInputRef.current?.click()}
            disabled={isImportingBackup}
            className="px-3.5 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <Upload className="w-3.5 h-3.5" />
            {isImportingBackup ? 'Restoring...' : 'Import Backup'}
          </button>
          <input
            ref={backupInputRef}
            type="file"
            accept=".vaultbackup,.json"
            className="hidden"
            onChange={(e) => {
              if (e.target.files && e.target.files[0]) {
                handleImportBackup(e.target.files[0]);
              }
            }}
          />
        </div>
      </section>

      {/* 5. Danger Zone */}
      <section className="bg-zinc-950 border border-red-950/60 rounded-2xl p-5 shadow-sm space-y-3">
        <h3 className="text-sm font-bold text-red-400 flex items-center gap-2">
          <Trash2 className="w-4 h-4" /> Danger Zone
        </h3>
        <p className="text-xs text-zinc-500">
          Permanent actions that cannot be undone. Please ensure you have exported any needed backups first.
        </p>

        <div className="flex flex-col sm:flex-row gap-3 pt-2">
          <button
            onClick={handleClearAllData}
            className="flex-1 py-2.5 px-3 rounded-xl bg-red-950/40 hover:bg-red-950/80 border border-red-900/60 text-red-300 text-xs font-semibold transition-colors"
          >
            Clear All Vault Files
          </button>
          <button
            onClick={handleFactoryReset}
            className="flex-1 py-2.5 px-3 rounded-xl bg-red-950/70 hover:bg-red-900 border border-red-800 text-red-200 text-xs font-semibold transition-colors"
          >
            Factory Reset App & PIN
          </button>
        </div>
      </section>
    </div>
  );
};
