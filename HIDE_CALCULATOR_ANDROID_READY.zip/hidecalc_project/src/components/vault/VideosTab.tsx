import React, { useState, useRef, useTransition } from 'react';
import { Upload, Film, Play, Search, Trash2, Plus, Clock } from 'lucide-react';
import { DecryptedFileItem } from '../../types';
import { encryptData } from '../../services/crypto';
import { saveFile } from '../../services/db';

interface VideosTabProps {
  videos: DecryptedFileItem[];
  vaultKey: CryptoKey;
  onRefresh: () => Promise<void>;
  onSelectVideo: (item: DecryptedFileItem) => void;
  onDeleteVideo: (id: string) => Promise<void>;
}

export const VideosTab: React.FC<VideosTabProps> = ({
  videos,
  vaultKey,
  onRefresh,
  onSelectVideo,
  onDeleteVideo,
}) => {
  const [, startTransition] = useTransition();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<{ current: number; total: number; filename: string } | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isDragging, setIsDragging] = useState(false);

  const filteredVideos = videos.filter((v) =>
    v.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleFileUpload = async (files: FileList | File[]) => {
    const validFiles = Array.from(files).filter(
      (f) => f.type.startsWith('video/') || /\.(mp4|mov|webm|mkv|avi|m4v)$/i.test(f.name)
    );

    if (validFiles.length === 0) {
      alert('Please select valid video files (MP4, MOV, WebM, MKV).');
      return;
    }

    setIsUploading(true);

    try {
      for (let i = 0; i < validFiles.length; i++) {
        const file = validFiles[i];
        setUploadProgress({ current: i + 1, total: validFiles.length, filename: file.name });

        // Warning for huge files
        if (file.size > 200 * 1024 * 1024) {
          const proceed = window.confirm(
            `"${file.name}" is over 200MB. Encrypting and storing large video files in browser IndexedDB may consume high memory. Do you wish to continue?`
          );
          if (!proceed) continue;
        }

        const arrayBuf = await file.arrayBuffer();

        // Encrypt with AES-256-GCM
        const encryptedData = await encryptData(arrayBuf, vaultKey);

        const newVaultItem = {
          id: `video_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
          name: file.name,
          type: 'video' as const,
          mimeType: file.type || 'video/mp4',
          size: file.size,
          createdAt: Date.now(),
          encryptedData,
        };

        await saveFile(newVaultItem);
      }

      await onRefresh();
    } catch (err) {
      console.error('Video encryption error:', err);
      alert('Failed to encrypt video. Browser storage quota may have been exceeded.');
    } finally {
      setIsUploading(false);
      setUploadProgress(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const formatSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  return (
    <div className="space-y-4">
      {/* Top Controls */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search videos..."
            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl pl-9 pr-4 py-2 text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:border-zinc-600 transition-colors"
          />
        </div>

        <button
          onClick={() => fileInputRef.current?.click()}
          disabled={isUploading}
          className="px-4 py-2 rounded-xl bg-white hover:bg-zinc-200 active:scale-95 text-black text-xs font-bold flex items-center gap-1.5 transition-all shadow-md shrink-0 disabled:opacity-50"
        >
          <Plus className="w-4 h-4" />
          Import Video
        </button>
        <input
          ref={fileInputRef}
          type="file"
          accept="video/*"
          multiple
          className="hidden"
          onChange={(e) => {
            if (e.target.files) {
              const files = e.target.files;
              startTransition(() => {
                handleFileUpload(files);
              });
            }
          }}
        />
      </div>

      {/* Uploading Status */}
      {isUploading && uploadProgress && (
        <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800 space-y-2 animate-in fade-in">
          <div className="flex justify-between text-xs text-zinc-300">
            <span className="truncate max-w-[240px]">Encrypting "{uploadProgress.filename}"...</span>
            <span className="font-mono">{uploadProgress.current} / {uploadProgress.total}</span>
          </div>
          <div className="w-full h-1.5 bg-zinc-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-white transition-all duration-200 animate-pulse"
              style={{
                width: `${(uploadProgress.current / uploadProgress.total) * 100}%`,
              }}
            />
          </div>
        </div>
      )}

      {/* Drag & Drop Area */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={(e) => {
          e.preventDefault();
          setIsDragging(false);
          if (e.dataTransfer.files) {
            startTransition(() => {
              handleFileUpload(e.dataTransfer.files);
            });
          }
        }}
        className={`border-2 border-dashed rounded-2xl p-6 text-center transition-all ${
          isDragging
            ? 'border-white bg-zinc-900'
            : 'border-zinc-800 hover:border-zinc-700 bg-zinc-950/60'
        }`}
      >
        <div className="w-12 h-12 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center mx-auto text-zinc-400 mb-2">
          <Film className="w-6 h-6 text-zinc-300" />
        </div>
        <p className="text-sm font-medium text-white mb-1">
          Drop secret videos here or click Import Video
        </p>
        <p className="text-xs text-zinc-500">
          Encrypted client-side with AES-256-GCM. Never shared or uploaded externally.
        </p>
      </div>

      {/* Video Grid */}
      {filteredVideos.length === 0 ? (
        <div className="text-center py-12 px-4 rounded-2xl bg-zinc-950/40 border border-zinc-900">
          <div className="w-14 h-14 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center mx-auto text-zinc-500 mb-3">
            <Film className="w-7 h-7" />
          </div>
          <h3 className="text-sm font-semibold text-zinc-300 mb-1">No Videos in Secret Vault</h3>
          <p className="text-xs text-zinc-500 max-w-sm mx-auto mb-4">
            Upload private clips, screen recordings, or media notes. Accessible only after entering your PIN.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredVideos.map((video) => (
            <div
              key={video.id}
              onClick={() => onSelectVideo(video)}
              className="group relative rounded-2xl overflow-hidden bg-zinc-900 border border-zinc-800/80 hover:border-zinc-600 transition-all cursor-pointer shadow-md select-none flex flex-col"
            >
              {/* Video Thumbnail / Preview Container */}
              <div className="relative aspect-video bg-black flex items-center justify-center overflow-hidden">
                <video
                  src={video.blobUrl}
                  preload="metadata"
                  className="w-full h-full object-cover opacity-85 group-hover:opacity-100 group-hover:scale-105 transition-all duration-300 pointer-events-none"
                />

                {/* Center Play Button Badge */}
                <div className="absolute w-12 h-12 rounded-full bg-white/90 text-black flex items-center justify-center shadow-2xl transition-transform group-hover:scale-110">
                  <Play className="w-5 h-5 ml-0.5 fill-black" />
                </div>

                {/* Duration / Type pill */}
                <div className="absolute bottom-2 right-2 px-2 py-0.5 rounded bg-black/80 text-[10px] text-zinc-300 font-mono flex items-center gap-1">
                  <Clock className="w-3 h-3 text-zinc-400" />
                  <span>{formatSize(video.size)}</span>
                </div>
              </div>

              {/* Bottom metadata */}
              <div className="p-3.5 flex items-center justify-between gap-2 bg-zinc-950">
                <div className="overflow-hidden">
                  <h4 className="text-xs font-semibold text-white truncate group-hover:text-zinc-200">
                    {video.name}
                  </h4>
                  <p className="text-[10px] text-zinc-500 font-mono mt-0.5">
                    {new Date(video.createdAt).toLocaleDateString()}
                  </p>
                </div>

                <button
                  onClick={async (e) => {
                    e.stopPropagation();
                    if (window.confirm(`Delete "${video.name}"?`)) {
                      await onDeleteVideo(video.id);
                    }
                  }}
                  className="p-1.5 text-zinc-500 hover:text-red-400 rounded-lg hover:bg-zinc-900 transition-colors shrink-0"
                  title="Delete Video"
                  aria-label="Delete Video"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
