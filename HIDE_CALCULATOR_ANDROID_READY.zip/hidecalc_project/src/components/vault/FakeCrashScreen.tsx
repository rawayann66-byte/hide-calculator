import React, { useState } from 'react';
import { AlertOctagon, RefreshCw } from 'lucide-react';

interface FakeCrashScreenProps {
  onRecover: () => void;
}

export const FakeCrashScreen: React.FC<FakeCrashScreenProps> = ({ onRecover }) => {
  const [tapCount, setTapCount] = useState(0);

  const handleSecretTap = () => {
    const next = tapCount + 1;
    if (next >= 3) {
      onRecover();
    } else {
      setTapCount(next);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black text-white flex flex-col items-center justify-center p-6 select-none font-mono">
      <div className="max-w-md w-full bg-zinc-950 border border-zinc-800 rounded-3xl p-6 sm:p-8 space-y-4 shadow-2xl">
        <div className="w-12 h-12 rounded-2xl bg-zinc-900 border border-zinc-700 flex items-center justify-center text-zinc-400">
          <AlertOctagon className="w-6 h-6 text-zinc-300" />
        </div>

        <div>
          <h2 className="text-base font-bold text-white tracking-wide">SYSTEM DIAGNOSTIC FAULT</h2>
          <p
            onClick={handleSecretTap}
            className="text-xs text-zinc-500 mt-1 cursor-default hover:text-zinc-400 transition-colors"
          >
            ERR_CALC_REGISTER_CORRUPT: 0x80040154
          </p>
        </div>

        <div className="p-3.5 bg-black border border-zinc-900 rounded-xl text-[11px] text-zinc-400 leading-relaxed space-y-1">
          <p>Thread 0x0041: Stack pointer invalid</p>
          <p>Register RAX: 0x0000000000000000</p>
          <p>Subsystem halt: Arithmetic unit suspended.</p>
        </div>

        <div className="pt-2 flex justify-between items-center text-xs">
          <button
            onClick={onRecover}
            className="px-4 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 font-semibold flex items-center gap-1.5 transition-colors border border-zinc-800"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Restart Calculator
          </button>
          <span className="text-[10px] text-zinc-600">ID: 884-01-A</span>
        </div>
      </div>
    </div>
  );
};
