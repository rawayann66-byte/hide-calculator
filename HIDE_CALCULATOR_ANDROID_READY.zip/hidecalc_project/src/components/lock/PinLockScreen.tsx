import React, { useState, useEffect, useCallback } from 'react';
import { Lock, Delete, ShieldCheck, ShieldAlert, Check, ArrowRight } from 'lucide-react';
import { VaultConfig } from '../../types';
import { verifyPin, hashPin, generateRandomSalt, deriveVaultKey } from '../../services/crypto';
import { saveConfig } from '../../services/db';
import { playTactileClick, playUnlockChime } from '../../services/audio';

interface PinLockScreenProps {
  config: VaultConfig;
  onConfigUpdated: (newConfig: VaultConfig) => void;
  onUnlock: (pin: string, key: CryptoKey) => void;
}

export const PinLockScreen: React.FC<PinLockScreenProps> = ({
  config,
  onConfigUpdated,
  onUnlock,
}) => {
  const hasSavedPin = Boolean(config.isSetup && config.pinHash && config.pinSalt);

  // Flow step: 'enter' (for returning users) or 'create' | 'confirm' | 'success' (for first-time setup)
  const [step, setStep] = useState<'enter' | 'create' | 'confirm' | 'success'>(() => {
    return hasSavedPin ? 'enter' : 'create';
  });

  const [pin, setPin] = useState<string>('');
  const [createdPin, setCreatedPin] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [isShaking, setIsShaking] = useState<boolean>(false);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  // Sync step ONLY if config changes externally (e.g. storage loaded or reset)
  useEffect(() => {
    const isConfigured = Boolean(config.isSetup && config.pinHash && config.pinSalt);
    if (isConfigured) {
      setStep((curr) => (curr === 'success' ? 'success' : 'enter'));
    } else {
      setStep((curr) => (curr === 'confirm' ? 'confirm' : 'create'));
    }
  }, [config.isSetup, config.pinHash, config.pinSalt]);

  const triggerError = (msg: string) => {
    setErrorMessage(msg);
    setIsShaking(true);
    setTimeout(() => {
      setIsShaking(false);
    }, 500);
  };

  // 1. Verify PIN for returning users
  const verifyReturningPin = useCallback(
    async (codeToVerify: string) => {
      if (isProcessing) return;
      setIsProcessing(true);
      setErrorMessage(null);

      try {
        const isValid = await verifyPin(codeToVerify, config.pinSalt, config.pinHash);
        if (isValid) {
          playUnlockChime(config.hapticSound);
          const key = await deriveVaultKey(codeToVerify, config.vaultSalt);
          onUnlock(codeToVerify, key);
        } else {
          triggerError('Wrong Secret Code');
          setPin('');
        }
      } catch {
        triggerError('Wrong Secret Code');
        setPin('');
      } finally {
        setIsProcessing(false);
      }
    },
    [config, onUnlock, isProcessing]
  );

  // 2. Save new PIN permanently in IndexedDB and localStorage
  const finalizePinCreation = useCallback(
    async (confirmedPin: string) => {
      if (isProcessing) return;
      setIsProcessing(true);
      setErrorMessage(null);
      setSuccessMessage('PIN Created Successfully');
      setStep('success');

      try {
        const pinSalt = generateRandomSalt(16);
        const vaultSalt = generateRandomSalt(16);
        const pinHash = await hashPin(confirmedPin, pinSalt);

        const updated = await saveConfig({
          isSetup: true,
          pinSalt,
          pinHash,
          vaultSalt,
        });

        onConfigUpdated(updated);
        playUnlockChime(config.hapticSound);

        const key = await deriveVaultKey(confirmedPin, vaultSalt);

        // Transition smoothly to Calculator screen
        setTimeout(() => {
          onUnlock(confirmedPin, key);
        }, 600);
      } catch (err) {
        console.error('Failed to create PIN:', err);
        setSuccessMessage(null);
        setStep('create');
        triggerError('Failed to save PIN. Please try again.');
        setIsProcessing(false);
      }
    },
    [config.hapticSound, onConfigUpdated, onUnlock, isProcessing]
  );

  // 3. Numeric Keypad: Register every tap cleanly into React state without clearing
  const handleDigit = useCallback(
    (digit: string) => {
      if (isProcessing) return;
      playTactileClick(config.hapticSound);
      setErrorMessage(null);

      setPin((prev) => {
        if (prev.length >= 4) return prev;
        return prev + digit;
      });
    },
    [config.hapticSound, isProcessing]
  );

  // 4. Backspace: Remove only the last digit
  const handleDelete = useCallback(() => {
    if (isProcessing) return;
    playTactileClick(config.hapticSound);
    setErrorMessage(null);
    setPin((prev) => (prev.length > 0 ? prev.slice(0, -1) : ''));
  }, [config.hapticSound, isProcessing]);

  // 5. Action Click: NEXT -> CONFIRM -> UNLOCK
  const handleActionClick = useCallback(async () => {
    if (isProcessing) return;

    if (pin.length !== 4) {
      triggerError('Please enter 4 digits');
      return;
    }

    playTactileClick(config.hapticSound);

    if (step === 'create') {
      // Move to Confirm PIN screen
      setCreatedPin(pin);
      setPin('');
      setStep('confirm');
      setErrorMessage(null);
    } else if (step === 'confirm') {
      // Check if both PINs match
      if (pin !== createdPin) {
        triggerError('Codes do not match. Try again.');
        setPin('');
        return;
      }
      // Matches! Securely persist
      await finalizePinCreation(pin);
    } else if (step === 'enter') {
      // Verify returning PIN
      await verifyReturningPin(pin);
    }
  }, [isProcessing, pin, step, createdPin, config.hapticSound, finalizePinCreation, verifyReturningPin]);

  // 6. Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key >= '0' && e.key <= '9') {
        e.preventDefault();
        handleDigit(e.key);
      } else if (e.key === 'Backspace') {
        e.preventDefault();
        handleDelete();
      } else if (e.key === 'Enter') {
        e.preventDefault();
        handleActionClick();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleDigit, handleDelete, handleActionClick]);

  // Subtitle message
  const getDisplayMessage = () => {
    if (successMessage) return successMessage;
    if (step === 'create') return 'Create New 4-Digit Secret Code';
    if (step === 'confirm') return 'Confirm Your Secret Code';
    return 'Enter Your 4-Digit Secret Code';
  };

  const getActionButtonLabel = () => {
    if (isProcessing) return '...';
    if (step === 'create') return 'Next';
    if (step === 'confirm') return 'Confirm';
    return 'Unlock';
  };

  return (
    <div className="fixed inset-0 z-50 bg-black text-white flex flex-col justify-between items-center px-4 py-8 sm:py-12 select-none overflow-y-auto">
      {/* Brand Header */}
      <div className="flex flex-col items-center text-center mt-2 sm:mt-6">
        <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-3xl bg-zinc-950 border border-zinc-800 flex items-center justify-center text-white mb-4 shadow-2xl shadow-zinc-900/40">
          <Lock className="w-7 h-7 sm:w-8 sm:h-8 text-white" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white font-mono">
          HIDE CALCULATOR
        </h1>

        {/* Dynamic Display Message */}
        <p
          className={`text-sm sm:text-base mt-2.5 font-medium tracking-wide transition-all ${
            successMessage
              ? 'text-emerald-400 font-semibold flex items-center justify-center gap-1.5'
              : 'text-zinc-300'
          }`}
        >
          {successMessage && <Check className="w-4 h-4 text-emerald-400" />}
          {getDisplayMessage()}
        </p>

        {/* First-Time Setup Indicator */}
        {!hasSavedPin && step !== 'enter' && step !== 'success' && (
          <div className="flex items-center gap-2 mt-3">
            <span
              className={`text-[11px] px-2.5 py-0.5 rounded-full font-mono transition-colors ${
                step === 'create'
                  ? 'bg-white text-black font-semibold shadow-sm'
                  : 'bg-zinc-900 text-zinc-500'
              }`}
            >
              1. Create
            </span>
            <span
              className={`text-[11px] px-2.5 py-0.5 rounded-full font-mono transition-colors ${
                step === 'confirm'
                  ? 'bg-white text-black font-semibold shadow-sm'
                  : 'bg-zinc-900 text-zinc-500'
              }`}
            >
              2. Confirm
            </span>
          </div>
        )}

        {/* Return to Step 1 Button if on Confirm */}
        {step === 'confirm' && (
          <button
            type="button"
            onClick={() => {
              setPin('');
              setCreatedPin('');
              setStep('create');
              setErrorMessage(null);
            }}
            className="text-xs text-zinc-400 hover:text-white underline underline-offset-2 transition-colors mt-2"
          >
            ← Change Initial PIN
          </button>
        )}
      </div>

      {/* 4 Digit Boxes: One dot for each entered digit */}
      <div className="flex flex-col items-center my-6 sm:my-8 w-full max-w-xs">
        <div
          className={`flex items-center justify-center gap-3.5 sm:gap-4 transition-transform duration-200 ${
            isShaking ? 'translate-x-[-8px] text-red-400' : ''
          }`}
        >
          {[0, 1, 2, 3].map((index) => {
            const hasDigit = pin.length > index;
            const isCurrent = pin.length === index;
            return (
              <div
                key={index}
                className={`w-14 h-16 sm:w-16 sm:h-18 rounded-2xl flex items-center justify-center font-mono text-2xl font-bold transition-all duration-150 border ${
                  errorMessage
                    ? 'border-red-500 bg-red-950/20 text-red-400 shadow-md shadow-red-950/40'
                    : successMessage
                    ? 'border-emerald-500 bg-emerald-950/20 text-emerald-400 shadow-md shadow-emerald-950/40'
                    : hasDigit
                    ? 'border-white bg-zinc-900 text-white shadow-lg shadow-white/5'
                    : isCurrent
                    ? 'border-zinc-500 bg-zinc-950 ring-2 ring-white/20'
                    : 'border-zinc-800 bg-zinc-950/60 text-zinc-600'
                }`}
              >
                {hasDigit ? (
                  <span className="w-3.5 h-3.5 rounded-full bg-white inline-block animate-in zoom-in-75 duration-100" />
                ) : (
                  <span className="text-zinc-700 text-base">_</span>
                )}
              </div>
            );
          })}
        </div>

        {/* Error message slot */}
        <div className="h-8 mt-4 flex items-center justify-center text-center">
          {errorMessage && (
            <div className="flex items-center gap-1.5 text-xs text-red-400 font-semibold animate-in fade-in">
              <ShieldAlert className="w-4 h-4 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}
        </div>
      </div>

      {/* Numeric Keypad: 3 columns (0-9, Backspace, Action) */}
      <div className="w-full max-w-xs space-y-3 mb-3">
        <div className="grid grid-cols-3 gap-3">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
            <button
              key={digit}
              type="button"
              onClick={() => handleDigit(digit)}
              disabled={isProcessing}
              className="h-14 sm:h-16 rounded-2xl bg-zinc-900/90 hover:bg-zinc-800 active:scale-95 text-white text-xl sm:text-2xl font-mono font-medium transition-all border border-zinc-800/80 shadow-md flex items-center justify-center active:bg-zinc-700 disabled:opacity-50"
              aria-label={`Digit ${digit}`}
            >
              {digit}
            </button>
          ))}

          {/* Delete / Backspace */}
          <button
            type="button"
            onClick={handleDelete}
            disabled={isProcessing || pin.length === 0}
            className="h-14 sm:h-16 rounded-2xl bg-zinc-900 hover:bg-zinc-800 active:scale-95 text-zinc-300 hover:text-white transition-all border border-zinc-800/80 shadow-md flex items-center justify-center disabled:opacity-40 disabled:cursor-not-allowed"
            title="Delete last digit"
            aria-label="Delete"
          >
            <Delete className="w-6 h-6" />
          </button>

          {/* 0 */}
          <button
            type="button"
            onClick={() => handleDigit('0')}
            disabled={isProcessing}
            className="h-14 sm:h-16 rounded-2xl bg-zinc-900/90 hover:bg-zinc-800 active:scale-95 text-white text-xl sm:text-2xl font-mono font-medium transition-all border border-zinc-800/80 shadow-md flex items-center justify-center active:bg-zinc-700 disabled:opacity-50"
            aria-label="Digit 0"
          >
            0
          </button>

          {/* Action Button: NEXT / CONFIRM / UNLOCK */}
          <button
            type="button"
            onClick={handleActionClick}
            disabled={isProcessing || pin.length < 4}
            className={`h-14 sm:h-16 rounded-2xl font-bold text-sm transition-all shadow-lg flex flex-col items-center justify-center active:scale-95 ${
              pin.length === 4
                ? 'bg-white hover:bg-zinc-200 text-black shadow-white/10 ring-2 ring-white/50 cursor-pointer'
                : 'bg-zinc-900 border border-zinc-800 text-zinc-500 cursor-not-allowed opacity-60'
            }`}
            aria-label={getActionButtonLabel()}
          >
            <span className="text-xs uppercase tracking-wider font-mono flex items-center gap-1">
              {getActionButtonLabel()}
              {pin.length === 4 && <ArrowRight className="w-3.5 h-3.5 ml-0.5" />}
            </span>
          </button>
        </div>
      </div>

      {/* Footer */}
      <div className="flex flex-col items-center gap-1.5 pb-2 text-center">
        <div className="text-[11px] text-zinc-600 font-mono flex items-center gap-1.5">
          <ShieldCheck className="w-3.5 h-3.5 text-zinc-500" />
          <span>Client-Side Salted PBKDF2 · AES-256-GCM</span>
        </div>
      </div>
    </div>
  );
};
