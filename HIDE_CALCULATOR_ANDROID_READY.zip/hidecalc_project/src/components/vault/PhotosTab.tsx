import React, { useState, useRef, useTransition } from 'react';
import { Upload, Image as ImageIcon, Search, Trash2, Eye, Plus, AlertCircle } from 'lucide-react';
import { DecryptedFileItem } from '../../types';
import { encryptData } from '../../services/crypto';
import { saveFile } from '../../services/db';

interface PhotosTabProps {
  photos: DecryptedFileItem[];
  vaultKey: CryptoKey;
  onRefresh: () => Promise<void>;
  onSelectPhoto: (item: DecryptedFileItem) => void;
  onDeletePhoto: (id: string) => Promise<void>;
}

export const PhotosTab: React.FC<PhotosTabProps> = ({
  photos,
  vaultKey,
  onRefresh,
  onSelectPhoto,
  onDeletePhoto,
}) => {
  const [, startTransition] = useTransition();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<{ current: number; total: number } | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isDragging, setIsDragging] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  const filteredPhotos = photos.filter((p) =>
    p.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleFileUpload = async (files: FileList | File[]) => {
    const validFiles = Array.from(files).filter((f) => f.type.startsWith('image/'));
    if (validFiles.length === 0) {
      alert('Please select valid image files (JPG, PNG, WebP, GIF, SVG).');
      return;
    }

    setIsUploading(true);
    setUploadProgress({ current: 0, total: validFiles.length });

    try {
      for (let i = 0; i < validFiles.length; i++) {
        const file = validFiles[i];
        const arrayBuf = await file.arrayBuffer();

        // Encrypt image with AES-256-GCM
        const encryptedData = await encryptData(arrayBuf, vaultKey);

        const newVaultItem = {
          id: `photo_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
          name: file.name,
          type: 'photo' as const,
          mimeType: file.type || 'image/jpeg',
          size: file.size,
          createdAt: Date.now(),
          encryptedData,
        };

        await saveFile(newVaultItem);
        setUploadProgress({ current: i + 1, total: validFiles.length });
      }

      await onRefresh();
    } catch (err) {
      console.error('Photo encryption/save error:', err);
      alert('Failed to encrypt and store some images. Please check available browser storage.');
    } finally {
      setIsUploading(false);
      setUploadProgress(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const toggleSelect = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleBatchDelete = async () => {
    if (selectedIds.size === 0) return;
    if (window.confirm(`Delete ${selectedIds.size} selected photo(s)? This cannot be undone.`)) {
      for (const id of selectedIds) {
        await onDeletePhoto(id);
      }
      setSelectedIds(new Set());
    }
  };

  const formatSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  return (
    <div className="space-y-4">
      {/* Action and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        {/* Search */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search photos..."
            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl pl-9 pr-4 py-2 text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:border-zinc-600 transition-colors"
          />
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2">
          {selectedIds.size > 0 && (
            <button
              onClick={handleBatchDelete}
              className="px-3.5 py-2 rounded-xl bg-red-950/80 hover:bg-red-900 border border-red-800 text-red-200 text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              <Trash2 className="w-3.5 h-3.5" />
              Delete ({selectedIds.size})
            </button>
          )}

          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={isUploading}
            className="px-4 py-2 rounded-xl bg-white hover:bg-zinc-200 active:scale-95 text-black text-xs font-bold flex items-center gap-1.5 transition-all shadow-md shrink-0 disabled:opacity-50"
          >
            <Plus className="w-4 h-4" />
            Import Photos
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            multiple
            className="hidden"
            onChange={(e) => {
              if (e.target.files) {
                const files = e.target.files;
                startTransition(() => {
                  handleFileUpload(files);
                });
              }
            }}
          />
        </div>
      </div>

      {/* Uploading Progress Bar */}
      {isUploading && uploadProgress && (
        <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800 space-y-2 animate-in fade-in">
          <div className="flex justify-between text-xs text-zinc-300">
            <span>Encrypting and storing photos...</span>
            <span className="font-mono">{uploadProgress.current} / {uploadProgress.total}</span>
          </div>
          <div className="w-full h-1.5 bg-zinc-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-white transition-all duration-200"
              style={{
                width: `${(uploadProgress.current / uploadProgress.total) * 100}%`,
              }}
            />
          </div>
        </div>
      )}

      {/* Drag & Drop Zone */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={(e) => {
          e.preventDefault();
          setIsDragging(false);
          if (e.dataTransfer.files) {
            startTransition(() => {
              handleFileUpload(e.dataTransfer.files);
            });
          }
        }}
        className={`border-2 border-dashed rounded-2xl p-6 text-center transition-all ${
          isDragging
            ? 'border-white bg-zinc-900'
            : 'border-zinc-800 hover:border-zinc-700 bg-zinc-950/60'
        }`}
      >
        <div className="w-12 h-12 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center mx-auto text-zinc-400 mb-2">
          <Upload className="w-6 h-6 text-zinc-300" />
        </div>
        <p className="text-sm font-medium text-white mb-1">
          Drop secret photos here or click Import Photos
        </p>
        <p className="text-xs text-zinc-500">
          Encrypted immediately with AES-256-GCM before writing to local IndexedDB
        </p>
      </div>

      {/* Photo Grid */}
      {filteredPhotos.length === 0 ? (
        <div className="text-center py-12 px-4 rounded-2xl bg-zinc-950/40 border border-zinc-900">
          <div className="w-14 h-14 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center mx-auto text-zinc-500 mb-3">
            <ImageIcon className="w-7 h-7" />
          </div>
          <h3 className="text-sm font-semibold text-zinc-300 mb-1">No Photos in Secret Vault</h3>
          <p className="text-xs text-zinc-500 max-w-sm mx-auto mb-4">
            Upload private photos, screenshots, and receipts. They are protected by your 4-digit PIN.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 sm:gap-4">
          {filteredPhotos.map((photo) => {
            const isSelected = selectedIds.has(photo.id);
            return (
              <div
                key={photo.id}
                onClick={() => onSelectPhoto(photo)}
                className={`group relative aspect-square rounded-2xl overflow-hidden bg-zinc-900 border transition-all cursor-pointer select-none ${
                  isSelected
                    ? 'border-white ring-2 ring-white/50 shadow-lg'
                    : 'border-zinc-800/80 hover:border-zinc-600 hover:shadow-md'
                }`}
              >
                {/* Photo Thumbnail */}
                <img
                  src={photo.blobUrl}
                  alt={photo.name}
                  loading="lazy"
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                />

                {/* Scrim Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity p-2.5 flex flex-col justify-between">
                  {/* Top Checkbox */}
                  <div className="flex justify-end">
                    <button
                      onClick={(e) => toggleSelect(photo.id, e)}
                      className={`w-6 h-6 rounded-lg flex items-center justify-center transition-colors border ${
                        isSelected
                          ? 'bg-white border-white text-black'
                          : 'bg-black/60 border-zinc-500 text-white hover:border-white'
                      }`}
                      aria-label="Select photo"
                    >
                      {isSelected ? '✓' : ''}
                    </button>
                  </div>

                  {/* Bottom details */}
                  <div className="text-left">
                    <p className="text-xs font-semibold text-white truncate">{photo.name}</p>
                    <p className="text-[10px] text-zinc-400 font-mono">{formatSize(photo.size)}</p>
                  </div>
                </div>

                {/* Persistent selection badge if selected */}
                {isSelected && (
                  <div className="absolute top-2 right-2 w-6 h-6 rounded-lg bg-white text-black text-xs font-bold flex items-center justify-center shadow">
                    ✓
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
